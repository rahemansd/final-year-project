import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './face-attendance-system.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)