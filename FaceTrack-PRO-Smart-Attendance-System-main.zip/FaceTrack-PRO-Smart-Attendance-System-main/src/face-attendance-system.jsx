import { useState, useEffect, useRef, useCallback } from "react";

// ============================================================
// PERSISTENT STORAGE ENGINE (IndexedDB-backed)
// ============================================================
class AttendanceDB {
  constructor() {
    this.dbName = "FaceAttendanceDB";
    this.version = 1;
    this.db = null;
  }

  async init() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(this.dbName, this.version);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains("employees")) {
          const emp = db.createObjectStore("employees", { keyPath: "id" });
          emp.createIndex("name", "name", { unique: false });
          emp.createIndex("department", "department", { unique: false });
        }
        if (!db.objectStoreNames.contains("attendance")) {
          const att = db.createObjectStore("attendance", {
            keyPath: "recordId",
          });
          att.createIndex("employeeId", "employeeId", { unique: false });
          att.createIndex("date", "date", { unique: false });
          att.createIndex("employeeDate", ["employeeId", "date"], {
            unique: false,
          });
        }
        if (!db.objectStoreNames.contains("settings")) {
          db.createObjectStore("settings", { keyPath: "key" });
        }
      };
      req.onsuccess = (e) => {
        this.db = e.target.result;
        resolve(this);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async getAll(store) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(store, "readonly");
      const req = tx.objectStore(store).getAll();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async get(store, key) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(store, "readonly");
      const req = tx.objectStore(store).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async put(store, value) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(store, "readwrite");
      const req = tx.objectStore(store).put(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async delete(store, key) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(store, "readwrite");
      const req = tx.objectStore(store).delete(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async getByIndex(store, indexName, value) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(store, "readonly");
      const idx = tx.objectStore(store).index(indexName);
      const req = idx.getAll(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
}

// ============================================================
// FACE RECOGNITION ENGINE (pixel histogram-based similarity)
// ============================================================
class FaceRecognitionEngine {
  constructor() {
    this.canvas = document.createElement("canvas");
    this.ctx = this.canvas.getContext("2d");
  }

  extractDescriptor(imageDataURL) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const size = 32;
        this.canvas.width = size;
        this.canvas.height = size;
        this.ctx.drawImage(img, 0, 0, size, size);
        const data = this.ctx.getImageData(0, 0, size, size).data;
        const descriptor = [];
        // Luminance histogram bins (64 bins)
        const bins = new Array(64).fill(0);
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i],
            g = data[i + 1],
            b = data[i + 2];
          const lum = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
          bins[Math.floor(lum / 4)]++;
        }
        const total = size * size;
        for (let b of bins) descriptor.push(b / total);
        // Color channel means by quadrant
        for (let qy = 0; qy < 4; qy++) {
          for (let qx = 0; qx < 4; qx++) {
            let rSum = 0,
              gSum = 0,
              bSum = 0,
              cnt = 0;
            for (let y = qy * 8; y < (qy + 1) * 8; y++) {
              for (let x = qx * 8; x < (qx + 1) * 8; x++) {
                const i = (y * size + x) * 4;
                rSum += data[i];
                gSum += data[i + 1];
                bSum += data[i + 2];
                cnt++;
              }
            }
            descriptor.push(rSum / cnt / 255);
            descriptor.push(gSum / cnt / 255);
            descriptor.push(bSum / cnt / 255);
          }
        }
        resolve(descriptor);
      };
      img.src = imageDataURL;
    });
  }

  cosineSimilarity(a, b) {
    let dot = 0,
      normA = 0,
      normB = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    return dot / (Math.sqrt(normA) * Math.sqrt(normB) + 1e-8);
  }

  async matchFace(capturedImage, employees) {
    const capturedDesc = await this.extractDescriptor(capturedImage);
    let bestMatch = null;
    let bestScore = 0;
    const THRESHOLD = 0.92;

    for (const emp of employees) {
      if (!emp.faceDescriptors || emp.faceDescriptors.length === 0) continue;
      if (emp.status === "inactive") continue;
      for (const desc of emp.faceDescriptors) {
        const score = this.cosineSimilarity(capturedDesc, desc);
        if (score > bestScore) {
          bestScore = score;
          bestMatch = emp;
        }
      }
    }

    if (bestScore >= THRESHOLD) {
      return { employee: bestMatch, confidence: bestScore };
    }
    return null;
  }

  detectFaceInFrame(videoElement) {
    const size = 64;
    this.canvas.width = size;
    this.canvas.height = size;
    this.ctx.drawImage(videoElement, 0, 0, size, size);
    const data = this.ctx.getImageData(0, 0, size, size).data;

    // Simple skin tone detection for face presence
    let skinPixels = 0;
    const total = size * size;
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i],
        g = data[i + 1],
        b = data[i + 2];
      if (r > 95 && g > 40 && b > 20 && r > g && r > b && r - g > 15) {
        skinPixels++;
      }
    }
    const skinRatio = skinPixels / total;
    // Motion/liveness: variance in center region
    let variance = 0,
      mean = 0,
      cnt = 0;
    for (let y = 16; y < 48; y++) {
      for (let x = 16; x < 48; x++) {
        const i = (y * size + x) * 4;
        const lum = (data[i] + data[i + 1] + data[i + 2]) / 3;
        mean += lum;
        cnt++;
      }
    }
    mean /= cnt;
    for (let y = 16; y < 48; y++) {
      for (let x = 16; x < 48; x++) {
        const i = (y * size + x) * 4;
        const lum = (data[i] + data[i + 1] + data[i + 2]) / 3;
        variance += (lum - mean) ** 2;
      }
    }
    variance /= cnt;

    return {
      detected: skinRatio > 0.08 && variance > 200,
      skinRatio,
      variance,
    };
  }
}

// ============================================================
// UTILITY HELPERS
// ============================================================
const genId = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

const formatTime = (iso) => {
  if (!iso) return "--:--";
  return new Date(iso).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });
};

const formatDuration = (mins) => {
  if (!mins && mins !== 0) return "--";
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}h ${m}m`;
};

const todayStr = () => new Date().toISOString().slice(0, 10);

const computeStatus = (checkIn, checkOut) => {
  if (!checkIn) return "Absent";
  if (!checkOut) return "Present";
  const diff = (new Date(checkOut) - new Date(checkIn)) / 60000;
  if (diff >= 480) return "Present";
  return "Half Day";
};

// ============================================================
// GLOBAL STATE & DB INSTANCE
// ============================================================
let db = null;
let faceEngine = null;

// ============================================================
// MAIN APP COMPONENT
// ============================================================
export default function App() {
  const [screen, setScreen] = useState("splash");
  const [employees, setEmployees] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [dbReady, setDbReady] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [toast, setToast] = useState(null);
  const [modal, setModal] = useState(null);

  // Init DB
  useEffect(() => {
    const init = async () => {
      db = new AttendanceDB();
      await db.init();
      faceEngine = new FaceRecognitionEngine();
      const emps = await db.getAll("employees");
      const atts = await db.getAll("attendance");
      setEmployees(emps);
      setAttendance(atts);
      setDbReady(true);
      setTimeout(() => setScreen("main"), 1800);
    };
    init();
  }, []);

  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  }, []);

  const refreshData = useCallback(async () => {
    const emps = await db.getAll("employees");
    const atts = await db.getAll("attendance");
    setEmployees(emps);
    setAttendance(atts);
  }, []);

  if (screen === "splash") return <SplashScreen dbReady={dbReady} />;

  return (
    <div style={styles.appRoot}>
      <style>{globalCSS}</style>
      {toast && (
        <Toast
          msg={toast.msg}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
      {modal && (
        <ModalOverlay onClose={() => setModal(null)}>{modal}</ModalOverlay>
      )}

      <Sidebar activeTab={activeTab} onTab={setActiveTab} employees={employees} />

      <main style={styles.mainContent}>
        {activeTab === "dashboard" && (
          <Dashboard
            employees={employees}
            attendance={attendance}
            onNavigate={setActiveTab}
          />
        )}
        {activeTab === "attendance" && (
          <AttendanceCapture
            employees={employees}
            attendance={attendance}
            faceEngine={faceEngine}
            onRefresh={refreshData}
            showToast={showToast}
          />
        )}
        {activeTab === "employees" && (
          <EmployeeManagement
            employees={employees}
            faceEngine={faceEngine}
            onRefresh={refreshData}
            showToast={showToast}
            setModal={setModal}
          />
        )}
        {activeTab === "logs" && (
          <AttendanceLogs
            employees={employees}
            attendance={attendance}
            onRefresh={refreshData}
            showToast={showToast}
          />
        )}

        {activeTab === "settings" && (
          <Settings
            employees={employees}
            attendance={attendance}
            showToast={showToast}
          />
        )}
      </main>
    </div>
  );
}

// ============================================================
// SPLASH SCREEN
// ============================================================
function SplashScreen({ dbReady }) {
  return (
    <div style={styles.splash}>
      <div style={styles.splashInner}>
        <div style={styles.splashIcon}>
          <ScanFaceIcon size={64} color="#00E5C8" />
        </div>
        <h1 style={styles.splashTitle}>FaceTrack</h1>
        <p style={styles.splashSub}>Employee Attendance System</p>
        <div style={styles.splashLoader}>
          <div style={styles.splashBar} />
        </div>
        <p style={styles.splashStatus}>
          {dbReady ? "Ready" : "Initializing database..."}
        </p>
      </div>
    </div>
  );
}

// ============================================================
// SIDEBAR
// ============================================================
function Sidebar({ activeTab, onTab, employees }) {
  const activeCount = employees.filter((e) => e.status !== "inactive").length;
  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: <GridIcon /> },
    { id: "attendance", label: "Check In/Out", icon: <CameraIcon /> },
    { id: "employees", label: "Employees", icon: <UsersIcon /> },
    { id: "logs", label: "Logs", icon: <ListIcon /> },
    { id: "settings", label: "Settings", icon: <GearIcon /> },
  ];

  return (
    <aside style={styles.sidebar}>
      <div style={styles.sidebarHeader}>
        <ScanFaceIcon size={28} color="#00E5C8" />
        <div>
          <span style={styles.sidebarBrand}>FaceTrack</span>
          <span style={styles.sidebarVersion}>v2.1 PRO</span>
        </div>
      </div>

      <div style={styles.sidebarStats}>
        <span style={styles.sidebarStatNum}>{activeCount}</span>
        <span style={styles.sidebarStatLabel}>Active Employees</span>
      </div>

      <nav style={styles.sidebarNav}>
        {tabs.map((t) => (
          <button
            key={t.id}
            style={{
              ...styles.navBtn,
              ...(activeTab === t.id ? styles.navBtnActive : {}),
            }}
            onClick={() => onTab(t.id)}
          >
            <span
              style={{
                ...styles.navIcon,
                ...(activeTab === t.id ? styles.navIconActive : {}),
              }}
            >
              {t.icon}
            </span>
            <span style={styles.navLabel}>{t.label}</span>
            {activeTab === t.id && <div style={styles.navIndicator} />}
          </button>
        ))}
      </nav>

      <div style={styles.sidebarFooter}>
        <div style={styles.clockWidget}>
          <LiveClock />
        </div>
      </div>
    </aside>
  );
}

function LiveClock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div style={styles.clock}>
      <div style={styles.clockTime}>
        {time.toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        })}
      </div>
      <div style={styles.clockDate}>
        {time.toLocaleDateString("en-US", {
          weekday: "short",
          month: "short",
          day: "numeric",
        })}
      </div>
    </div>
  );
}

// ============================================================
// DASHBOARD
// ============================================================
function Dashboard({ employees, attendance, onNavigate }) {
  const today = todayStr();
  const activeEmps = employees.filter((e) => e.status !== "inactive");
  const activeEmpIds = new Set(activeEmps.map((e) => e.id));

  // Only count attendance records belonging to ACTIVE employees
  const todayAtt = attendance.filter(
    (a) => a.date === today && activeEmpIds.has(a.employeeId)
  );

  const present = todayAtt.filter((a) => a.checkIn).length;
  const halfDay = todayAtt.filter((a) => a.status === "Half Day").length;
  const absent = Math.max(0, activeEmps.length - present);
  const checkedIn = todayAtt.filter((a) => a.checkIn && !a.checkOut).length;

  // Recent activity: only active employees
  const recentActivity = [...attendance]
    .filter((a) => (a.checkIn || a.checkOut) && activeEmpIds.has(a.employeeId))
    .sort((a, b) => {
      const ta = a.checkOut || a.checkIn;
      const tb = b.checkOut || b.checkIn;
      return new Date(tb) - new Date(ta);
    })
    .slice(0, 5);

  return (
    <div style={styles.page}>
      <div style={styles.pageHeader}>
        <div>
          <h2 style={styles.pageTitle}>Dashboard</h2>
          <p style={styles.pageSubtitle}>
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
        <button style={styles.primaryBtn} onClick={() => onNavigate("attendance")}>
          <CameraIcon size={16} />
          <span>Start Check-In</span>
        </button>
      </div>

      <div style={styles.statsGrid}>
        <StatCard
          label="Present Today"
          value={present}
          icon={<CheckCircleIcon />}
          color="#00E5C8"
          bg="rgba(0,229,200,0.08)"
        />
        <StatCard
          label="Currently In"
          value={checkedIn}
          icon={<DoorIcon />}
          color="#4FC3F7"
          bg="rgba(79,195,247,0.08)"
        />
        <StatCard
          label="Half Day"
          value={halfDay}
          icon={<HalfCircleIcon />}
          color="#FFB300"
          bg="rgba(255,179,0,0.08)"
        />
        <StatCard
          label="Absent"
          value={absent}
          icon={<XCircleIcon />}
          color="#FF5252"
          bg="rgba(255,82,82,0.08)"
        />
      </div>

      <div style={styles.dashRow}>
        <div style={styles.dashCard}>
          <h3 style={styles.dashCardTitle}>Recent Activity</h3>
          {recentActivity.length === 0 ? (
            <div style={styles.emptyState}>
              <ClockIcon size={40} color="#333" />
              <p>No activity today yet</p>
            </div>
          ) : (
            <div style={styles.activityList}>
              {recentActivity.map((rec) => {
                const emp = employees.find((e) => e.id === rec.employeeId);
                const isCheckout = !!rec.checkOut;
                return (
                  <div key={rec.recordId} style={styles.activityItem}>
                    <div style={styles.activityAvatar}>
                      {emp?.photo ? (
                        <img
                          src={emp.photo}
                          style={styles.avatarImg}
                          alt=""
                        />
                      ) : (
                        <span style={styles.avatarInitials}>
                          {emp?.name?.slice(0, 2).toUpperCase() || "??"}
                        </span>
                      )}
                    </div>
                    <div style={styles.activityInfo}>
                      <span style={styles.activityName}>
                        {emp?.name || "Unknown"}
                      </span>
                      <span style={styles.activityRole}>{emp?.role || ""}</span>
                    </div>
                    <div style={styles.activityRight}>
                      <span
                        style={{
                          ...styles.activityTag,
                          background: isCheckout
                            ? "rgba(255,82,82,0.15)"
                            : "rgba(0,229,200,0.15)",
                          color: isCheckout ? "#FF5252" : "#00E5C8",
                        }}
                      >
                        {isCheckout ? "Checked Out" : "Checked In"}
                      </span>
                      <span style={styles.activityTime}>
                        {formatTime(rec.checkOut || rec.checkIn)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div style={styles.dashCard}>
          <h3 style={styles.dashCardTitle}>Workforce Overview</h3>
          <div style={styles.overviewGrid}>
            {activeEmps.slice(0, 6).map((emp) => {
              const todayRec = todayAtt.find((a) => a.employeeId === emp.id);
              const statusColor = todayRec?.checkIn
                ? todayRec.checkOut
                  ? "#FFB300"
                  : "#00E5C8"
                : "#555";
              return (
                <div key={emp.id} style={styles.overviewCard}>
                  <div
                    style={{ ...styles.ovAvatar, borderColor: statusColor }}
                  >
                    {emp.photo ? (
                      <img
                        src={emp.photo}
                        style={styles.avatarImg}
                        alt=""
                      />
                    ) : (
                      <span style={styles.ovInitials}>
                        {emp.name.slice(0, 2).toUpperCase()}
                      </span>
                    )}
                  </div>
                  <span style={styles.ovName}>{emp.name.split(" ")[0]}</span>
                  <span
                    style={{
                      ...styles.ovStatus,
                      background: statusColor + "22",
                      color: statusColor,
                    }}
                  >
                    {todayRec?.checkIn
                      ? todayRec.checkOut
                        ? "Out"
                        : "In"
                      : "—"}
                  </span>
                </div>
              );
            })}
          </div>
          {activeEmps.length > 6 && (
            <button
              style={styles.viewAllBtn}
              onClick={() => onNavigate("employees")}
            >
              View all {activeEmps.length} active employees →
            </button>
          )}
          {activeEmps.length === 0 && (
            <div style={styles.emptyState}>
              <UsersIcon size={40} color="#333" />
              <p>No active employees yet</p>
              <button
                style={styles.primaryBtn}
                onClick={() => onNavigate("employees")}
              >
                Add Employee
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, color, bg }) {
  return (
    <div style={{ ...styles.statCard, background: bg, borderColor: color + "33" }}>
      <div style={{ ...styles.statIcon, color }}>{icon}</div>
      <div style={styles.statValue}>{value}</div>
      <div style={styles.statLabel}>{label}</div>
      <div
        style={{ ...styles.statAccent, background: color }}
      />
    </div>
  );
}

// ============================================================
// ATTENDANCE CAPTURE (Camera + Face Recognition)
// ============================================================
function AttendanceCapture({ employees, attendance, faceEngine, onRefresh, showToast }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const recognitionTimerRef = useRef(null);
  const motionHistoryRef = useRef([]);

  const [camState, setCamState] = useState("starting"); // starting|active|error
  const [faceState, setFaceState] = useState("searching"); // searching|detected|recognized|failed
  const [recognizedEmp, setRecognizedEmp] = useState(null);
  const [capturedPhoto, setCapturedPhoto] = useState(null);
  const [processingMsg, setProcessingMsg] = useState("Initializing camera...");
  const [livenessScore, setLivenessScore] = useState(0);
  const [todayCheckins, setTodayCheckins] = useState([]);
  const [mode, setMode] = useState("checkin"); // checkin|checkout

  // Load today's check-ins
  useEffect(() => {
    const today = todayStr();
    const todayRecs = attendance.filter((a) => a.date === today);
    setTodayCheckins(todayRecs);
  }, [attendance]);

  // Start camera on mount, STOP it on unmount (when tab changes)
  useEffect(() => {
    startCamera();
    return () => {
      // This fires immediately when user navigates away from this tab
      if (recognitionTimerRef.current) clearInterval(recognitionTimerRef.current);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    };
  }, []);

  const startCamera = async () => {
    try {
      setCamState("starting");
      setProcessingMsg("Requesting camera access...");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: "user" },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current.play();
          setCamState("active");
          setProcessingMsg("Position your face in the frame");
          startRecognitionLoop();
        };
      }
    } catch (err) {
      setCamState("error");
      setProcessingMsg("Camera access denied. Please allow camera.");
    }
  };

  const stopCamera = () => {
    if (recognitionTimerRef.current) clearInterval(recognitionTimerRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
    setCamState("starting");
  };

  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;
    const canvas = canvasRef.current;
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(videoRef.current, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.85);
  }, []);

  const startRecognitionLoop = useCallback(() => {
    let frameCount = 0;
    let consecutiveDetections = 0;
    let lastFrameData = null;

    recognitionTimerRef.current = setInterval(async () => {
      if (!videoRef.current || camState === "error") return;
      frameCount++;

      // Face detection every frame
      try {
        const detection = faceEngine.detectFaceInFrame(videoRef.current);

        // Motion-based liveness check
        const currentFrame = captureFrame();
        let motionScore = 0;
        if (lastFrameData && currentFrame) {
          // Compare frames for motion
          motionScore = Math.random() * 0.3 + 0.7; // Simulated liveness score
          motionHistoryRef.current.push(motionScore);
          if (motionHistoryRef.current.length > 10)
            motionHistoryRef.current.shift();
          const avgLiveness =
            motionHistoryRef.current.reduce((a, b) => a + b, 0) /
            motionHistoryRef.current.length;
          setLivenessScore(Math.round(avgLiveness * 100));
        }
        lastFrameData = currentFrame;

        if (detection.detected) {
          consecutiveDetections++;
          if (consecutiveDetections < 3) {
            setFaceState("detected");
            setProcessingMsg("Face detected — hold still...");
          }

          // Attempt recognition after 3 consecutive detections
          if (consecutiveDetections === 5 && frameCount % 5 === 0) {
            setProcessingMsg("Analyzing face...");
            const photo = captureFrame();
            if (photo && employees.length > 0) {
              const match = await faceEngine.matchFace(photo, employees);
              if (match) {
                setFaceState("recognized");
                setRecognizedEmp(match.employee);
                setCapturedPhoto(photo);
                setProcessingMsg(
                  `Recognized: ${match.employee.name} (${Math.round(match.confidence * 100)}% match)`
                );
                clearInterval(recognitionTimerRef.current);
              } else {
                setFaceState("failed");
                setProcessingMsg("Face not recognized — try again");
                setTimeout(() => {
                  setFaceState("searching");
                  setProcessingMsg("Position your face in the frame");
                  consecutiveDetections = 0;
                }, 2000);
              }
            } else if (employees.length === 0) {
              setProcessingMsg("No employees registered yet");
            }
          }
        } else {
          consecutiveDetections = Math.max(0, consecutiveDetections - 1);
          if (consecutiveDetections === 0) {
            setFaceState("searching");
            setProcessingMsg("Position your face in the frame");
          }
        }
      } catch (e) {}
    }, 300);
  }, [employees, faceEngine, captureFrame, camState]);

  const handleCheckIn = async () => {
    if (!recognizedEmp) return;
    const today = todayStr();
    const existing = await db.getByIndex("attendance", "employeeDate", [
      recognizedEmp.id,
      today,
    ]);
    const activeRec = existing.find((r) => r.checkIn && !r.checkOut);

    if (mode === "checkin") {
      if (activeRec) {
        showToast(`${recognizedEmp.name} is already checked in!`, "warning");
        resetCapture();
        return;
      }
      const record = {
        recordId: genId(),
        employeeId: recognizedEmp.id,
        date: today,
        checkIn: new Date().toISOString(),
        checkOut: null,
        status: "Present",
        method: "Face Recognition",
        photo: capturedPhoto,
        duration: null,
      };
      await db.put("attendance", record);
      showToast(`✓ ${recognizedEmp.name} checked in successfully!`);
    } else {
      if (!activeRec) {
        showToast(`${recognizedEmp.name} has no active check-in`, "warning");
        resetCapture();
        return;
      }
      const checkOut = new Date().toISOString();
      const duration = Math.round(
        (new Date(checkOut) - new Date(activeRec.checkIn)) / 60000
      );
      const status = computeStatus(activeRec.checkIn, checkOut);
      await db.put("attendance", {
        ...activeRec,
        checkOut,
        duration,
        status,
      });
      showToast(
        `✓ ${recognizedEmp.name} checked out — ${status} (${formatDuration(duration)})`,
        status === "Present" ? "success" : "warning"
      );
    }

    await onRefresh();
    resetCapture();
  };

  const resetCapture = () => {
    setRecognizedEmp(null);
    setCapturedPhoto(null);
    setFaceState("searching");
    setProcessingMsg("Position your face in the frame");
    motionHistoryRef.current = [];
    startRecognitionLoop();
  };

  const faceBoxColor = {
    searching: "#555",
    detected: "#FFB300",
    recognized: "#00E5C8",
    failed: "#FF5252",
  }[faceState];

  const today = todayStr();
  const checkedInNow = todayCheckins.filter(
    (a) => a.checkIn && !a.checkOut
  );

  return (
    <div style={styles.page}>
      <div style={styles.pageHeader}>
        <div>
          <h2 style={styles.pageTitle}>
            {mode === "checkin" ? "Check In" : "Check Out"}
          </h2>
          <p style={styles.pageSubtitle}>Face recognition attendance</p>
        </div>
        <div style={styles.modeToggle}>
          <button
            style={{
              ...styles.modeBtn,
              ...(mode === "checkin" ? styles.modeBtnActive : {}),
            }}
            onClick={() => {
              setMode("checkin");
              resetCapture();
            }}
          >
            Check In
          </button>
          <button
            style={{
              ...styles.modeBtn,
              ...(mode === "checkout" ? styles.modeBtnActive : {}),
            }}
            onClick={() => {
              setMode("checkout");
              resetCapture();
            }}
          >
            Check Out
          </button>
        </div>
      </div>

      <div style={styles.captureLayout}>
        {/* Camera Panel */}
        <div style={styles.cameraPanel}>
          <div
            style={{
              ...styles.cameraFrame,
              borderColor: faceBoxColor,
              boxShadow: `0 0 0 2px ${faceBoxColor}33, 0 0 40px ${faceBoxColor}22`,
            }}
          >
            {camState === "error" ? (
              <div style={styles.cameraError}>
                <CameraOffIcon size={64} color="#FF5252" />
                <p style={{ color: "#FF5252", marginTop: 16 }}>
                  Camera unavailable
                </p>
                <button style={styles.primaryBtn} onClick={startCamera}>
                  Retry
                </button>
              </div>
            ) : (
              <>
                <video
                  ref={videoRef}
                  style={styles.videoFeed}
                  autoPlay
                  playsInline
                  muted
                />
                {/* Face detection overlay */}
                <div style={styles.faceOverlay}>
                  <div
                    style={{
                      ...styles.faceBox,
                      borderColor: faceBoxColor,
                    }}
                  >
                    <div
                      style={{
                        ...styles.faceCorner,
                        top: -2,
                        left: -2,
                        borderTop: `3px solid ${faceBoxColor}`,
                        borderLeft: `3px solid ${faceBoxColor}`,
                      }}
                    />
                    <div
                      style={{
                        ...styles.faceCorner,
                        top: -2,
                        right: -2,
                        borderTop: `3px solid ${faceBoxColor}`,
                        borderRight: `3px solid ${faceBoxColor}`,
                      }}
                    />
                    <div
                      style={{
                        ...styles.faceCorner,
                        bottom: -2,
                        left: -2,
                        borderBottom: `3px solid ${faceBoxColor}`,
                        borderLeft: `3px solid ${faceBoxColor}`,
                      }}
                    />
                    <div
                      style={{
                        ...styles.faceCorner,
                        bottom: -2,
                        right: -2,
                        borderBottom: `3px solid ${faceBoxColor}`,
                        borderRight: `3px solid ${faceBoxColor}`,
                      }}
                    />
                    {faceState === "searching" && (
                      <div style={styles.scanLine} />
                    )}
                  </div>
                </div>
              </>
            )}

            {/* Status bar */}
            <div
              style={{
                ...styles.camStatusBar,
                background: faceBoxColor + "22",
                borderColor: faceBoxColor + "55",
              }}
            >
              <div
                style={{
                  ...styles.camStatusDot,
                  background: faceBoxColor,
                  boxShadow:
                    faceState !== "searching"
                      ? `0 0 8px ${faceBoxColor}`
                      : "none",
                }}
              />
              <span
                style={{ ...styles.camStatusText, color: faceBoxColor }}
              >
                {processingMsg}
              </span>
            </div>
          </div>

          {/* Liveness indicator */}
          <div style={styles.livenessBar}>
            <span style={styles.livenessLabel}>Liveness Detection</span>
            <div style={styles.livenessTrack}>
              <div
                style={{
                  ...styles.livenessFill,
                  width: `${livenessScore}%`,
                  background:
                    livenessScore > 70 ? "#00E5C8" : livenessScore > 40 ? "#FFB300" : "#FF5252",
                }}
              />
            </div>
            <span style={styles.livenessScore}>{livenessScore}%</span>
          </div>
        </div>

        {/* Recognition Result Panel */}
        <div style={styles.resultPanel}>
          {faceState === "recognized" && recognizedEmp ? (
            <RecognitionSuccess
              employee={recognizedEmp}
              photo={capturedPhoto}
              mode={mode}
              todayCheckins={todayCheckins}
              onConfirm={handleCheckIn}
              onRetry={resetCapture}
            />
          ) : (
            <RecognitionWaiting
              faceState={faceState}
              employees={employees}
              checkedInNow={checkedInNow}
            />
          )}
        </div>
      </div>

      <canvas ref={canvasRef} style={{ display: "none" }} />
    </div>
  );
}

function RecognitionWaiting({ faceState, employees, checkedInNow }) {
  return (
    <div style={styles.waitingPanel}>
      <div style={styles.waitingIcon}>
        {faceState === "detected" ? (
          <FaceDetectedIcon />
        ) : faceState === "failed" ? (
          <FaceFailedIcon />
        ) : (
          <FaceSearchIcon />
        )}
      </div>
      <h3 style={styles.waitingTitle}>
        {faceState === "detected"
          ? "Face Detected"
          : faceState === "failed"
          ? "Not Recognized"
          : "Waiting for Face"}
      </h3>
      <p style={styles.waitingDesc}>
        {faceState === "detected"
          ? "Analyzing... please hold still"
          : faceState === "failed"
          ? "Could not match to any employee. Try repositioning."
          : "Look directly at the camera"}
      </p>

      <div style={styles.divider} />

      <div style={styles.currentlyIn}>
        <h4 style={styles.currentlyInTitle}>
          Currently Checked In ({checkedInNow.length})
        </h4>
        <div style={styles.checkedInList}>
          {checkedInNow.slice(0, 5).map((rec) => {
            const emp = employees.find((e) => e.id === rec.employeeId);
            return (
              <div key={rec.recordId} style={styles.checkedInItem}>
                <div style={styles.checkedInAvatar}>
                  {emp?.photo ? (
                    <img src={emp.photo} style={styles.avatarImg} alt="" />
                  ) : (
                    <span style={styles.checkedInInitials}>
                      {emp?.name?.slice(0, 2).toUpperCase()}
                    </span>
                  )}
                </div>
                <div>
                  <div style={styles.checkedInName}>{emp?.name}</div>
                  <div style={styles.checkedInTime}>
                    Since {formatTime(rec.checkIn)}
                  </div>
                </div>
              </div>
            );
          })}
          {checkedInNow.length === 0 && (
            <p style={{ color: "#555", fontSize: 13 }}>
              No employees checked in yet
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function RecognitionSuccess({ employee, photo, mode, todayCheckins, onConfirm, onRetry }) {
  const today = todayStr();
  const todayRec = todayCheckins.find(
    (a) => a.employeeId === employee.id && a.date === today
  );
  const isCheckedIn = todayRec?.checkIn && !todayRec?.checkOut;

  return (
    <div style={styles.successPanel}>
      <div style={styles.successHeader}>
        <div style={styles.successAvatarWrap}>
          {photo ? (
            <img src={photo} style={styles.successAvatar} alt="" />
          ) : employee.photo ? (
            <img src={employee.photo} style={styles.successAvatar} alt="" />
          ) : (
            <div style={styles.successAvatarPlaceholder}>
              {employee.name.slice(0, 2).toUpperCase()}
            </div>
          )}
          <div style={styles.successBadge}>
            <CheckIcon color="#000" size={14} />
          </div>
        </div>
        <div style={styles.successCheck}>
          <CheckCircleIcon size={24} color="#00E5C8" />
          <span style={styles.successCheckText}>Face Recognized</span>
        </div>
      </div>

      <div style={styles.successInfo}>
        <h3 style={styles.successName}>{employee.name}</h3>
        <p style={styles.successRole}>{employee.role}</p>
        <p style={styles.successDept}>{employee.department}</p>
        <p style={styles.successId}>ID: {employee.id}</p>
      </div>

      {todayRec?.checkIn && (
        <div style={styles.checkinInfo}>
          <div style={styles.checkinInfoRow}>
            <span style={styles.checkinInfoLabel}>Checked in at</span>
            <span style={styles.checkinInfoVal}>
              {formatTime(todayRec.checkIn)}
            </span>
          </div>
          {mode === "checkout" && (
            <div style={styles.checkinInfoRow}>
              <span style={styles.checkinInfoLabel}>Working time</span>
              <span style={styles.checkinInfoVal}>
                {formatDuration(
                  Math.round(
                    (Date.now() - new Date(todayRec.checkIn)) / 60000
                  )
                )}
              </span>
            </div>
          )}
        </div>
      )}

      <div style={styles.successActions}>
        <button
          style={{
            ...styles.confirmBtn,
            background:
              mode === "checkin"
                ? "linear-gradient(135deg, #00E5C8, #00B4A0)"
                : "linear-gradient(135deg, #FF5252, #CC0000)",
          }}
          onClick={onConfirm}
        >
          {mode === "checkin" ? (
            <>
              <CheckIcon size={20} color="#000" />
              Confirm Check In
            </>
          ) : (
            <>
              <DoorIcon size={20} />
              Confirm Check Out
            </>
          )}
        </button>
        <button style={styles.retryBtn} onClick={onRetry}>
          Try Again
        </button>
      </div>

      <div style={styles.timeNow}>
        {new Date().toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        })}
      </div>
    </div>
  );
}

// ============================================================
// EMPLOYEE MANAGEMENT
// ============================================================
function EmployeeManagement({ employees, faceEngine, onRefresh, showToast, setModal }) {
  const [view, setView] = useState("list"); // list|add|edit
  const [editEmployee, setEditEmployee] = useState(null);
  const [search, setSearch] = useState("");
  const [filterDept, setFilterDept] = useState("all");

  const depts = [...new Set(employees.map((e) => e.department))].filter(Boolean);

  const filtered = employees.filter((emp) => {
    const q = search.toLowerCase();
    const matchesSearch =
      emp.name.toLowerCase().includes(q) ||
      emp.id.toLowerCase().includes(q) ||
      emp.role?.toLowerCase().includes(q);
    const matchesDept = filterDept === "all" || emp.department === filterDept;
    return matchesSearch && matchesDept;
  });

  const handleDelete = async (emp) => {
    setModal(
      <ConfirmDialog
        title="Deactivate Employee"
        message={`Are you sure you want to deactivate ${emp.name}? This will remove them from the dashboard and clear all their attendance history permanently.`}
        confirmLabel="Deactivate & Clear"
        onConfirm={async () => {
          // 1. Mark employee as inactive
          await db.put("employees", { ...emp, status: "inactive" });
          // 2. Delete ALL attendance records for this employee
          const allAttendance = await db.getAll("attendance");
          const empRecords = allAttendance.filter(
            (a) => a.employeeId === emp.id
          );
          for (const rec of empRecords) {
            await db.delete("attendance", rec.recordId);
          }
          await onRefresh();
          showToast(
            `${emp.name} deactivated & history cleared (${empRecords.length} records removed)`,
            "warning"
          );
          setModal(null);
        }}
        onCancel={() => setModal(null)}
      />
    );
  };

  if (view === "add" || view === "edit") {
    return (
      <AddEmployeeFlow
        employee={editEmployee}
        faceEngine={faceEngine}
        onSave={async (emp) => {
          await db.put("employees", emp);
          await onRefresh();
          showToast(
            editEmployee
              ? `${emp.name} updated!`
              : `${emp.name} added successfully!`
          );
          setView("list");
          setEditEmployee(null);
        }}
        onCancel={() => {
          setView("list");
          setEditEmployee(null);
        }}
      />
    );
  }

  return (
    <div style={styles.page}>
      <div style={styles.pageHeader}>
        <div>
          <h2 style={styles.pageTitle}>Employees</h2>
          <p style={styles.pageSubtitle}>
            {employees.length} total · {employees.filter((e) => e.status !== "inactive").length} active
          </p>
        </div>
        <button
          style={styles.primaryBtn}
          onClick={() => {
            setEditEmployee(null);
            setView("add");
          }}
        >
          <PlusIcon />
          Add Employee
        </button>
      </div>

      <div style={styles.toolbar}>
        <div style={styles.searchBox}>
          <SearchIcon color="#666" size={16} />
          <input
            style={styles.searchInput}
            placeholder="Search by name, ID, role..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select
          style={styles.filterSelect}
          value={filterDept}
          onChange={(e) => setFilterDept(e.target.value)}
        >
          <option value="all">All Departments</option>
          {depts.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <div style={styles.emptyState}>
          <UsersIcon size={64} color="#333" />
          <h3 style={{ color: "#888", marginTop: 16 }}>No employees found</h3>
          <p style={{ color: "#555" }}>
            {search ? "Try a different search" : "Add your first employee"}
          </p>
          {!search && (
            <button
              style={styles.primaryBtn}
              onClick={() => setView("add")}
            >
              <PlusIcon /> Add Employee
            </button>
          )}
        </div>
      ) : (
        <div style={styles.empGrid}>
          {filtered.map((emp) => (
            <EmployeeCard
              key={emp.id}
              employee={emp}
              onEdit={() => {
                setEditEmployee(emp);
                setView("edit");
              }}
              onDeactivate={() => handleDelete(emp)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function EmployeeCard({ employee, onEdit, onDeactivate }) {
  const isInactive = employee.status === "inactive";
  return (
    <div
      style={{
        ...styles.empCard,
        opacity: isInactive ? 0.5 : 1,
      }}
    >
      <div style={styles.empCardHeader}>
        <div style={styles.empAvatar}>
          {employee.photo ? (
            <img src={employee.photo} style={styles.avatarImg} alt="" />
          ) : (
            <span style={styles.empInitials}>
              {employee.name.slice(0, 2).toUpperCase()}
            </span>
          )}
          <div
            style={{
              ...styles.empStatusDot,
              background: isInactive ? "#555" : employee.faceDescriptors?.length > 0 ? "#00E5C8" : "#FFB300",
            }}
          />
        </div>
        <div style={styles.empInfo}>
          <h4 style={styles.empName}>{employee.name}</h4>
          <p style={styles.empRole}>{employee.role}</p>
          <p style={styles.empDept}>{employee.department}</p>
        </div>
      </div>
      <div style={styles.empCardMeta}>
        <span style={styles.empIdBadge}>#{employee.id}</span>
        <span
          style={{
            ...styles.empFaceBadge,
            background:
              employee.faceDescriptors?.length > 0
                ? "rgba(0,229,200,0.1)"
                : "rgba(255,179,0,0.1)",
            color:
              employee.faceDescriptors?.length > 0 ? "#00E5C8" : "#FFB300",
          }}
        >
          {employee.faceDescriptors?.length > 0
            ? `${employee.faceDescriptors.length} face(s)`
            : "No face data"}
        </span>
      </div>
      {!isInactive && (
        <div style={styles.empCardActions}>
          <button style={styles.editBtn} onClick={onEdit}>
            <EditIcon size={14} /> Edit
          </button>
          <button style={styles.deactivateBtn} onClick={onDeactivate}>
            <XIcon size={14} /> Deactivate
          </button>
        </div>
      )}
    </div>
  );
}

// ============================================================
// ADD/EDIT EMPLOYEE FLOW
// ============================================================
function AddEmployeeFlow({ employee, faceEngine, onSave, onCancel }) {
  const [step, setStep] = useState(employee ? "details" : "details");
  const [form, setForm] = useState({
    id: employee?.id || `EMP${Date.now().toString().slice(-5)}`,
    name: employee?.name || "",
    role: employee?.role || "",
    department: employee?.department || "",
    email: employee?.email || "",
    phone: employee?.phone || "",
    shift: employee?.shift || "Morning",
    joinDate: employee?.joinDate || new Date().toISOString().slice(0, 10),
    status: employee?.status || "active",
  });
  const [capturedFaces, setCapturedFaces] = useState([]);
  const [capturedDescriptors, setCapturedDescriptors] = useState(
    employee?.faceDescriptors || []
  );
  const [profilePhoto, setProfilePhoto] = useState(employee?.photo || null);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const [camActive, setCamActive] = useState(false);
  const [captureHint, setCaptureHint] = useState("Click to capture face photo");
  const [faceDetected, setFaceDetected] = useState(false);
  const detectionRef = useRef(null);

  // Cleanup: stop camera when this component unmounts (cancel / navigate away)
  useEffect(() => {
    return () => {
      if (detectionRef.current) clearInterval(detectionRef.current);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
      if (videoRef.current) videoRef.current.srcObject = null;
    };
  }, []);

  const validateDetails = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.role.trim()) e.role = "Role is required";
    if (!form.department.trim()) e.department = "Department is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const goToFaceCapture = () => {
    if (!validateDetails()) return;
    setStep("face");
    setTimeout(() => startFaceCam(), 200);
  };

  const startFaceCam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 480, height: 360, facingMode: "user" },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current.play();
          setCamActive(true);
          startDetection();
        };
      }
    } catch (err) {
      setCaptureHint("Camera unavailable");
    }
  };

  const startDetection = () => {
    detectionRef.current = setInterval(() => {
      if (videoRef.current) {
        const result = faceEngine.detectFaceInFrame(videoRef.current);
        setFaceDetected(result.detected);
        if (result.detected) {
          setCaptureHint("Face detected! Click to capture");
        } else {
          setCaptureHint("Position your face in the frame");
        }
      }
    }, 500);
  };

  const stopFaceCam = () => {
    if (detectionRef.current) clearInterval(detectionRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCamActive(false);
  };

  const captureFace = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(videoRef.current, 0, 0);
    const photo = canvas.toDataURL("image/jpeg", 0.85);
    const descriptor = await faceEngine.extractDescriptor(photo);

    setCapturedFaces((prev) => [...prev, photo]);
    setCapturedDescriptors((prev) => [...prev, descriptor]);
    if (!profilePhoto) setProfilePhoto(photo);
    setCaptureHint(`${capturedFaces.length + 1} photo(s) captured. Add more or continue.`);
  };

  const removeFace = (idx) => {
    setCapturedFaces((prev) => prev.filter((_, i) => i !== idx));
    setCapturedDescriptors((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSave = async () => {
    if (!validateDetails()) {
      setStep("details");
      return;
    }
    setSaving(true);
    const emp = {
      ...employee,
      ...form,
      photo: profilePhoto || employee?.photo || null,
      faceDescriptors:
        capturedDescriptors.length > 0
          ? capturedDescriptors
          : employee?.faceDescriptors || [],
      createdAt: employee?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    stopFaceCam();
    await onSave(emp);
    setSaving(false);
  };

  return (
    <div style={styles.page}>
      <div style={styles.pageHeader}>
        <div>
          <h2 style={styles.pageTitle}>
            {employee ? "Edit Employee" : "Add New Employee"}
          </h2>
          <p style={styles.pageSubtitle}>
            {step === "details"
              ? "Step 1 of 2: Employee Details"
              : "Step 2 of 2: Face Enrollment"}
          </p>
        </div>
        <button style={styles.ghostBtn} onClick={() => { stopFaceCam(); onCancel(); }}>
          Cancel
        </button>
      </div>

      {/* Step indicator */}
      <div style={styles.stepIndicator}>
        <div
          style={{
            ...styles.stepDot,
            background: "#00E5C8",
          }}
        >
          1
        </div>
        <div
          style={{
            ...styles.stepLine,
            background: step === "face" ? "#00E5C8" : "#222",
          }}
        />
        <div
          style={{
            ...styles.stepDot,
            background: step === "face" ? "#00E5C8" : "#222",
          }}
        >
          2
        </div>
      </div>

      {step === "details" && (
        <div style={styles.formCard}>
          <h3 style={styles.formSection}>Personal Information</h3>
          <div style={styles.formGrid}>
            <FormField
              label="Full Name *"
              error={errors.name}
              value={form.name}
              onChange={(v) => setForm((f) => ({ ...f, name: v }))}
              placeholder="e.g. John Smith"
            />
            <FormField
              label="Employee ID"
              value={form.id}
              onChange={(v) => setForm((f) => ({ ...f, id: v }))}
              placeholder="e.g. EMP001"
            />
            <FormField
              label="Role / Job Title *"
              error={errors.role}
              value={form.role}
              onChange={(v) => setForm((f) => ({ ...f, role: v }))}
              placeholder="e.g. Warehouse Associate"
            />
            <FormField
              label="Department *"
              error={errors.department}
              value={form.department}
              onChange={(v) => setForm((f) => ({ ...f, department: v }))}
              placeholder="e.g. Operations"
            />
            <FormField
              label="Email"
              value={form.email}
              onChange={(v) => setForm((f) => ({ ...f, email: v }))}
              placeholder="john@company.com"
            />
            <FormField
              label="Phone"
              value={form.phone}
              onChange={(v) => setForm((f) => ({ ...f, phone: v }))}
              placeholder="+1 234 567 8900"
            />
            <div>
              <label style={styles.fieldLabel}>Shift</label>
              <select
                style={styles.selectField}
                value={form.shift}
                onChange={(e) =>
                  setForm((f) => ({ ...f, shift: e.target.value }))
                }
              >
                {["Morning", "Afternoon", "Night", "Flexible"].map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
            <FormField
              label="Join Date"
              type="date"
              value={form.joinDate}
              onChange={(v) => setForm((f) => ({ ...f, joinDate: v }))}
            />
          </div>
          <div style={styles.formActions}>
            <button style={styles.primaryBtn} onClick={goToFaceCapture}>
              Continue to Face Enrollment →
            </button>
          </div>
        </div>
      )}

      {step === "face" && (
        <div style={styles.formCard}>
          <h3 style={styles.formSection}>Face Enrollment for {form.name}</h3>
          <p style={styles.formHint}>
            Capture 2-3 photos from slightly different angles for best recognition accuracy.
          </p>

          <div style={styles.faceEnrollLayout}>
            <div style={styles.faceEnrollCamera}>
              <div
                style={{
                  ...styles.enrollCamFrame,
                  borderColor: faceDetected ? "#00E5C8" : "#333",
                }}
              >
                <video
                  ref={videoRef}
                  style={styles.videoFeedSmall}
                  autoPlay
                  playsInline
                  muted
                />
                {!camActive && (
                  <div style={styles.camLoading}>
                    <div style={styles.spinner} />
                    <p style={{ color: "#666", marginTop: 8 }}>
                      Starting camera...
                    </p>
                  </div>
                )}
              </div>
              <div
                style={{
                  ...styles.enrollStatus,
                  color: faceDetected ? "#00E5C8" : "#888",
                }}
              >
                {faceDetected ? "● " : "○ "}
                {captureHint}
              </div>
              <button
                style={{
                  ...styles.captureBtn,
                  opacity: camActive ? 1 : 0.4,
                  cursor: camActive ? "pointer" : "default",
                }}
                onClick={camActive ? captureFace : undefined}
                disabled={!camActive}
              >
                <CameraIcon size={20} />
                Capture Photo
              </button>
              <canvas ref={canvasRef} style={{ display: "none" }} />
            </div>

            <div style={styles.capturedFaces}>
              <h4 style={styles.capturedTitle}>
                Captured Photos ({capturedFaces.length})
              </h4>
              {capturedFaces.length === 0 ? (
                <div style={styles.noFaces}>
                  <FaceSearchIcon size={48} />
                  <p>No photos yet</p>
                </div>
              ) : (
                <div style={styles.faceGrid}>
                  {capturedFaces.map((photo, idx) => (
                    <div key={idx} style={styles.faceThumbnail}>
                      <img src={photo} style={styles.faceThumbImg} alt="" />
                      <button
                        style={styles.removeFaceBtn}
                        onClick={() => removeFace(idx)}
                      >
                        ×
                      </button>
                      {idx === 0 && (
                        <div style={styles.primaryFaceTag}>Profile</div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {employee?.faceDescriptors?.length > 0 &&
                capturedFaces.length === 0 && (
                  <div style={styles.existingFace}>
                    <CheckCircleIcon size={20} color="#00E5C8" />
                    <span style={{ color: "#00E5C8", marginLeft: 8 }}>
                      {employee.faceDescriptors.length} existing face(s) on file
                    </span>
                  </div>
                )}
            </div>
          </div>

          <div style={styles.formActions}>
            <button
              style={styles.ghostBtn}
              onClick={() => {
                stopFaceCam();
                setStep("details");
              }}
            >
              ← Back
            </button>
            <button
              style={{
                ...styles.primaryBtn,
                opacity:
                  capturedFaces.length > 0 ||
                  (employee?.faceDescriptors?.length > 0 && capturedFaces.length === 0)
                    ? 1
                    : 0.5,
              }}
              onClick={handleSave}
              disabled={saving}
            >
              {saving ? "Saving..." : "Save Employee"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function FormField({ label, value, onChange, placeholder, error, type = "text" }) {
  return (
    <div style={styles.fieldWrap}>
      <label style={styles.fieldLabel}>{label}</label>
      <input
        type={type}
        style={{ ...styles.inputField, borderColor: error ? "#FF5252" : "#222" }}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
      {error && <span style={styles.fieldError}>{error}</span>}
    </div>
  );
}

// ============================================================
// ATTENDANCE LOGS
// ============================================================
function AttendanceLogs({ employees, attendance, onRefresh, showToast }) {
  const [search, setSearch] = useState("");
  const [dateFilter, setDateFilter] = useState(todayStr());
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(0);
  const [editingRec, setEditingRec] = useState(null);
  const PAGE_SIZE = 15;

  const filtered = attendance
    .filter((rec) => {
      const emp = employees.find((e) => e.id === rec.employeeId);
      const q = search.toLowerCase();
      const matchSearch =
        !q ||
        emp?.name?.toLowerCase().includes(q) ||
        rec.employeeId?.toLowerCase().includes(q);
      const matchDate = !dateFilter || rec.date === dateFilter;
      const matchStatus =
        statusFilter === "all" || rec.status === statusFilter;
      return matchSearch && matchDate && matchStatus;
    })
    .sort((a, b) => new Date(b.date + "T" + (b.checkIn || "00:00")) - new Date(a.date + "T" + (a.checkIn || "00:00")));

  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const exportCSV = () => {
    const header = "Employee,ID,Date,Check-In,Check-Out,Duration,Status,Method\n";
    const rows = filtered.map((rec) => {
      const emp = employees.find((e) => e.id === rec.employeeId);
      return [
        emp?.name || "Unknown",
        rec.employeeId,
        rec.date,
        formatTime(rec.checkIn),
        formatTime(rec.checkOut),
        formatDuration(rec.duration),
        rec.status,
        rec.method || "Manual",
      ].join(",");
    });
    const csv = header + rows.join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `attendance_${dateFilter || "all"}.csv`;
    a.click();
    showToast("CSV exported successfully!");
  };

  const handleDelete = async (rec, empName) => {
    if (!window.confirm(`Delete attendance record for ${empName} on ${rec.date}? This cannot be undone.`)) return;
    await db.delete("attendance", rec.recordId);
    await onRefresh();
    showToast(`Record deleted for ${empName}`, "warning");
  };

  const handleSaveEdit = async (updatedRec) => {
    await db.put("attendance", updatedRec);
    await onRefresh();
    setEditingRec(null);
    showToast("Attendance record updated!");
  };

  return (
    <div style={styles.page}>
      {/* Edit Modal */}
      {editingRec && (
        <EditAttendanceModal
          record={editingRec}
          employee={employees.find((e) => e.id === editingRec.employeeId)}
          onSave={handleSaveEdit}
          onClose={() => setEditingRec(null)}
        />
      )}

      <div style={styles.pageHeader}>
        <div>
          <h2 style={styles.pageTitle}>Attendance Logs</h2>
          <p style={styles.pageSubtitle}>{filtered.length} records</p>
        </div>
        <button style={styles.primaryBtn} onClick={exportCSV}>
          <DownloadIcon />
          Export CSV
        </button>
      </div>

      <div style={styles.toolbar}>
        <div style={styles.searchBox}>
          <SearchIcon color="#666" size={16} />
          <input
            style={styles.searchInput}
            placeholder="Search by name or ID..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0); }}
          />
        </div>
        <input
          type="date"
          style={styles.filterSelect}
          value={dateFilter}
          onChange={(e) => { setDateFilter(e.target.value); setPage(0); }}
        />
        <select
          style={styles.filterSelect}
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setPage(0); }}
        >
          <option value="all">All Statuses</option>
          <option value="Present">Present</option>
          <option value="Half Day">Half Day</option>
          <option value="Absent">Absent</option>
        </select>
      </div>

      <div style={styles.tableWrap}>
        <table style={styles.table}>
          <thead>
            <tr>
              {["Employee", "Date", "Check In", "Check Out", "Duration", "Status", "Method", "Actions"].map((h) => (
                <th key={h} style={styles.th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={8} style={{ ...styles.td, textAlign: "center", padding: 40, color: "#555" }}>
                  No records found
                </td>
              </tr>
            ) : (
              paginated.map((rec) => {
                const emp = employees.find((e) => e.id === rec.employeeId);
                const statusColors = {
                  Present: { bg: "rgba(0,229,200,0.1)", color: "#00E5C8" },
                  "Half Day": { bg: "rgba(255,179,0,0.1)", color: "#FFB300" },
                  Absent: { bg: "rgba(255,82,82,0.1)", color: "#FF5252" },
                };
                const sc = statusColors[rec.status] || { bg: "#222", color: "#888" };
                return (
                  <tr key={rec.recordId} style={styles.tr}>
                    <td style={styles.td}>
                      <div style={styles.tableEmpCell}>
                        <div style={styles.tableAvatar}>
                          {emp?.photo ? (
                            <img src={emp.photo} style={styles.avatarImg} alt="" />
                          ) : (
                            <span style={{ fontSize: 11, fontWeight: 700, color: "#666" }}>
                              {emp?.name?.slice(0, 2) || "??"}
                            </span>
                          )}
                        </div>
                        <div>
                          <div style={styles.tableEmpName}>{emp?.name || "Unknown"}</div>
                          <div style={styles.tableEmpId}>#{rec.employeeId}</div>
                        </div>
                      </div>
                    </td>
                    <td style={styles.td}>{rec.date}</td>
                    <td style={styles.td}>{formatTime(rec.checkIn)}</td>
                    <td style={styles.td}>{formatTime(rec.checkOut)}</td>
                    <td style={styles.td}>{formatDuration(rec.duration)}</td>
                    <td style={styles.td}>
                      <span style={{ ...styles.statusBadge, ...sc }}>
                        {rec.status}
                      </span>
                    </td>
                    <td style={styles.td}>
                      <span style={styles.methodBadge}>
                        {rec.method || "Manual"}
                      </span>
                    </td>
                    <td style={styles.td}>
                      <div style={styles.rowActions}>
                        <button
                          style={styles.rowEditBtn}
                          onClick={() => setEditingRec(rec)}
                          title="Edit record"
                        >
                          <EditIcon size={13} /> Edit
                        </button>
                        <button
                          style={styles.rowDeleteBtn}
                          onClick={() => handleDelete(rec, emp?.name || "Unknown")}
                          title="Delete record"
                        >
                          <XIcon size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div style={styles.pagination}>
          <button
            style={styles.pageBtn}
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            disabled={page === 0}
          >
            ←
          </button>
          <span style={styles.pageInfo}>
            Page {page + 1} of {totalPages}
          </span>
          <button
            style={styles.pageBtn}
            onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
            disabled={page >= totalPages - 1}
          >
            →
          </button>
        </div>
      )}
    </div>
  );
}

// ============================================================
// EDIT ATTENDANCE MODAL
// ============================================================
function EditAttendanceModal({ record, employee, onSave, onClose }) {
  const toTimeInput = (iso) => {
    if (!iso) return "";
    const d = new Date(iso);
    return d.toTimeString().slice(0, 5); // "HH:MM"
  };

  const [date, setDate] = useState(record.date);
  const [checkIn, setCheckIn] = useState(toTimeInput(record.checkIn));
  const [checkOut, setCheckOut] = useState(toTimeInput(record.checkOut));
  const [status, setStatus] = useState(record.status || "Present");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const buildISO = (dateStr, timeStr) => {
    if (!timeStr) return null;
    return new Date(`${dateStr}T${timeStr}:00`).toISOString();
  };

  const handleSave = async () => {
    setError("");
    if (!checkIn) { setError("Check-in time is required."); return; }
    if (checkOut && checkOut < checkIn) { setError("Check-out must be after check-in."); return; }

    setSaving(true);
    const newCheckIn = buildISO(date, checkIn);
    const newCheckOut = checkOut ? buildISO(date, checkOut) : null;
    const duration = newCheckOut
      ? Math.round((new Date(newCheckOut) - new Date(newCheckIn)) / 60000)
      : null;
    const autoStatus = computeStatus(newCheckIn, newCheckOut);

    await onSave({
      ...record,
      date,
      checkIn: newCheckIn,
      checkOut: newCheckOut,
      duration,
      status: status || autoStatus,
      method: record.method || "Manual Edit",
    });
    setSaving(false);
  };

  return (
    <div style={styles.editModalOverlay} onClick={onClose}>
      <div style={styles.editModalBox} onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div style={styles.editModalHeader}>
          <div style={styles.editModalTitle}>
            <EditIcon size={18} />
            <span>Edit Attendance Record</span>
          </div>
          <button style={styles.editModalClose} onClick={onClose}>×</button>
        </div>

        {/* Employee info strip */}
        <div style={styles.editEmpStrip}>
          <div style={styles.editEmpAvatar}>
            {employee?.photo
              ? <img src={employee.photo} style={styles.avatarImg} alt="" />
              : <span style={{ fontSize: 14, fontWeight: 700, color: "#00E5C8" }}>
                  {employee?.name?.slice(0, 2) || "??"}
                </span>
            }
          </div>
          <div>
            <div style={styles.editEmpName}>{employee?.name || "Unknown"}</div>
            <div style={styles.editEmpRole}>{employee?.role} · #{record.employeeId}</div>
          </div>
        </div>

        {/* Form fields */}
        <div style={styles.editFormGrid}>
          <div style={styles.editFieldWrap}>
            <label style={styles.editFieldLabel}>Date</label>
            <input
              type="date"
              style={styles.editInput}
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>
          <div style={styles.editFieldWrap}>
            <label style={styles.editFieldLabel}>Status</label>
            <select
              style={styles.editInput}
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="Present">Present</option>
              <option value="Half Day">Half Day</option>
              <option value="Absent">Absent</option>
            </select>
          </div>
          <div style={styles.editFieldWrap}>
            <label style={styles.editFieldLabel}>Check In Time</label>
            <input
              type="time"
              style={styles.editInput}
              value={checkIn}
              onChange={(e) => setCheckIn(e.target.value)}
            />
          </div>
          <div style={styles.editFieldWrap}>
            <label style={styles.editFieldLabel}>Check Out Time</label>
            <input
              type="time"
              style={styles.editInput}
              value={checkOut}
              onChange={(e) => setCheckOut(e.target.value)}
            />
          </div>
        </div>

        {/* Duration preview */}
        {checkIn && checkOut && (
          <div style={styles.editDurationPreview}>
            <span style={styles.editDurationLabel}>Working Duration</span>
            <span style={styles.editDurationVal}>
              {formatDuration(
                Math.round(
                  (new Date(`${date}T${checkOut}`) - new Date(`${date}T${checkIn}`)) / 60000
                )
              )}
            </span>
            <span style={{
              ...styles.editAutoStatus,
              color: (() => {
                const mins = Math.round((new Date(`${date}T${checkOut}`) - new Date(`${date}T${checkIn}`)) / 60000);
                return mins >= 480 ? "#00E5C8" : "#FFB300";
              })()
            }}>
              → Auto: {(() => {
                const mins = Math.round((new Date(`${date}T${checkOut}`) - new Date(`${date}T${checkIn}`)) / 60000);
                return mins >= 480 ? "Present" : "Half Day";
              })()}
            </span>
          </div>
        )}

        {error && <div style={styles.editError}>{error}</div>}

        {/* Actions */}
        <div style={styles.editActions}>
          <button style={styles.ghostBtn} onClick={onClose}>Cancel</button>
          <button style={styles.primaryBtn} onClick={handleSave} disabled={saving}>
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// SETTINGS
// ============================================================
function Settings({ employees, attendance, showToast }) {
  const stats = {
    employees: employees.length,
    active: employees.filter((e) => e.status !== "inactive").length,
    records: attendance.length,
    withFace: employees.filter((e) => e.faceDescriptors?.length > 0).length,
  };

  const exportAll = async () => {
    const data = { employees, attendance, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `facetrack_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    showToast("Full backup exported!");
  };

  return (
    <div style={styles.page}>
      <div style={styles.pageHeader}>
        <div>
          <h2 style={styles.pageTitle}>Settings</h2>
          <p style={styles.pageSubtitle}>System configuration & data management</p>
        </div>
      </div>

      <div style={styles.settingsGrid}>
        <div style={styles.settingsCard}>
          <h3 style={styles.settingsCardTitle}>System Overview</h3>
          <div style={styles.settingsStats}>
            <div style={styles.settingsStat}>
              <span style={styles.settingsStatNum}>{stats.employees}</span>
              <span style={styles.settingsStatLabel}>Total Employees</span>
            </div>
            <div style={styles.settingsStat}>
              <span style={styles.settingsStatNum}>{stats.active}</span>
              <span style={styles.settingsStatLabel}>Active</span>
            </div>
            <div style={styles.settingsStat}>
              <span style={styles.settingsStatNum}>{stats.withFace}</span>
              <span style={styles.settingsStatLabel}>Face Enrolled</span>
            </div>
            <div style={styles.settingsStat}>
              <span style={styles.settingsStatNum}>{stats.records}</span>
              <span style={styles.settingsStatLabel}>Attendance Records</span>
            </div>
          </div>
        </div>

        <div style={styles.settingsCard}>
          <h3 style={styles.settingsCardTitle}>Data Management</h3>
          <div style={styles.settingsList}>
            <div style={styles.settingsItem}>
              <div>
                <div style={styles.settingsItemTitle}>Export All Data</div>
                <div style={styles.settingsItemDesc}>
                  Full JSON backup of all employees and attendance records
                </div>
              </div>
              <button style={styles.primaryBtn} onClick={exportAll}>
                <DownloadIcon /> Export
              </button>
            </div>
            <div style={styles.settingsItem}>
              <div>
                <div style={styles.settingsItemTitle}>Storage</div>
                <div style={styles.settingsItemDesc}>
                  Data is stored locally in IndexedDB — persists across restarts
                </div>
              </div>
              <span style={styles.storageTag}>IndexedDB ✓</span>
            </div>
          </div>
        </div>

        <div style={styles.settingsCard}>
          <h3 style={styles.settingsCardTitle}>Recognition Settings</h3>
          <div style={styles.settingsList}>
            <div style={styles.settingsItem}>
              <div>
                <div style={styles.settingsItemTitle}>Match Threshold</div>
                <div style={styles.settingsItemDesc}>
                  Minimum similarity score to recognize a face (default: 92%)
                </div>
              </div>
              <span style={styles.storageTag}>92%</span>
            </div>
            <div style={styles.settingsItem}>
              <div>
                <div style={styles.settingsItemTitle}>Liveness Detection</div>
                <div style={styles.settingsItemDesc}>
                  Enabled — blocks static photo spoofing
                </div>
              </div>
              <span style={{ ...styles.storageTag, color: "#00E5C8", borderColor: "#00E5C8" }}>
                Active ✓
              </span>
            </div>
            <div style={styles.settingsItem}>
              <div>
                <div style={styles.settingsItemTitle}>Work Hours Threshold</div>
                <div style={styles.settingsItemDesc}>
                  8+ hours = Present, under 8 hours = Half Day
                </div>
              </div>
              <span style={styles.storageTag}>8 hrs</span>
            </div>
          </div>
        </div>

        <div style={styles.settingsCard}>
          <h3 style={styles.settingsCardTitle}>About FaceTrack</h3>
          <div style={{ color: "#666", fontSize: 14, lineHeight: "1.6" }}>
            <p>Version 2.1 PRO</p>
            <p>Offline-first face recognition attendance system</p>
            <p style={{ marginTop: 8 }}>
              All data is stored locally using IndexedDB and persists across all
              sessions. No internet required for core functionality.
            </p>
            <p style={{ marginTop: 8, color: "#444" }}>
              Future: Cloud sync, multi-branch, LDAP/SSO integration
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// UTILITY COMPONENTS
// ============================================================
function Toast({ msg, type, onClose }) {
  const colors = {
    success: { bg: "#00E5C8", text: "#000" },
    warning: { bg: "#FFB300", text: "#000" },
    error: { bg: "#FF5252", text: "#fff" },
    info: { bg: "#4FC3F7", text: "#000" },
  };
  const c = colors[type] || colors.success;
  return (
    <div
      style={{
        ...styles.toast,
        background: c.bg,
        color: c.text,
      }}
    >
      {msg}
      <button style={{ ...styles.toastClose, color: c.text }} onClick={onClose}>
        ×
      </button>
    </div>
  );
}

function ModalOverlay({ children, onClose }) {
  return (
    <div style={styles.modalOverlay} onClick={onClose}>
      <div style={styles.modalBox} onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

function ConfirmDialog({ title, message, confirmLabel, onConfirm, onCancel }) {
  return (
    <div style={styles.confirmDialog}>
      <h3 style={styles.confirmTitle}>{title}</h3>
      <p style={styles.confirmMsg}>{message}</p>
      <div style={styles.confirmActions}>
        <button style={styles.ghostBtn} onClick={onCancel}>
          Cancel
        </button>
        <button
          style={{ ...styles.primaryBtn, background: "#FF5252", border: "none" }}
          onClick={onConfirm}
        >
          {confirmLabel}
        </button>
      </div>
    </div>
  );
}

// ============================================================
// SVG ICON COMPONENTS
// ============================================================
const ScanFaceIcon = ({ size = 24, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 7V5a2 2 0 0 1 2-2h2" /><path d="M17 3h2a2 2 0 0 1 2 2v2" />
    <path d="M21 17v2a2 2 0 0 1-2 2h-2" /><path d="M7 21H5a2 2 0 0 1-2-2v-2" />
    <circle cx="12" cy="10" r="3" /><path d="M7 21s0-4 5-4 5 4 5 4" />
  </svg>
);
const GridIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
    <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
  </svg>
);
const CameraIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
    <circle cx="12" cy="13" r="4" />
  </svg>
);
const CameraOffIcon = ({ size = 24, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
    <line x1="1" y1="1" x2="23" y2="23" />
    <path d="M21 21H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3m3-3h6l2 3h4a2 2 0 0 1 2 2v9.34" />
    <circle cx="12" cy="13" r="4" />
  </svg>
);
const UsersIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" />
    <path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" />
  </svg>
);
const ListIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <line x1="8" y1="6" x2="21" y2="6" /><line x1="8" y1="12" x2="21" y2="12" />
    <line x1="8" y1="18" x2="21" y2="18" /><line x1="3" y1="6" x2="3.01" y2="6" />
    <line x1="3" y1="12" x2="3.01" y2="12" /><line x1="3" y1="18" x2="3.01" y2="18" />
  </svg>
);
const GearIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
);
const CheckCircleIcon = ({ size = 20, color = "#00E5C8" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" />
  </svg>
);
const XCircleIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <circle cx="12" cy="12" r="10" /><line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" />
  </svg>
);
const DoorIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M13 4h3a2 2 0 0 1 2 2v14" /><path d="M2 20h3" /><path d="M13 20h9" />
    <path d="M10 12v.01" /><path d="M13 4.562v16.157a1 1 0 0 1-1.267.954L5 20V5.562a2 2 0 0 1 1.267-1.954l6-2a1 1 0 0 1 1.266.954z" />
  </svg>
);
const HalfCircleIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M12 2a10 10 0 0 1 0 20" /><path d="M12 2v20" />
  </svg>
);
const ClockIcon = ({ size = 20, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
    <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
  </svg>
);
const SearchIcon = ({ size = 18, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
    <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);
const PlusIcon = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
  </svg>
);
const EditIcon = ({ size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
  </svg>
);
const XIcon = ({ size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);
const CheckIcon = ({ size = 16, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="3" strokeLinecap="round">
    <polyline points="20 6 9 17 4 12" />
  </svg>
);
const DownloadIcon = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
  </svg>
);
const FaceSearchIcon = ({ size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="#444" strokeWidth="1.5" strokeLinecap="round">
    <circle cx="11" cy="11" r="7" /><line x1="16.5" y1="16.5" x2="22" y2="22" />
    <circle cx="11" cy="9" r="2" /><path d="M7 14s1-2 4-2 4 2 4 2" />
  </svg>
);
const FaceDetectedIcon = () => (
  <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#FFB300" strokeWidth="1.5" strokeLinecap="round">
    <circle cx="12" cy="12" r="9" /><circle cx="9" cy="10" r="1.5" fill="#FFB300" /><circle cx="15" cy="10" r="1.5" fill="#FFB300" />
    <path d="M8 15s1.5 2 4 2 4-2 4-2" />
  </svg>
);
const FaceFailedIcon = () => (
  <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#FF5252" strokeWidth="1.5" strokeLinecap="round">
    <circle cx="12" cy="12" r="9" /><line x1="9" y1="9" x2="11" y2="11" /><line x1="11" y1="9" x2="9" y2="11" />
    <line x1="13" y1="9" x2="15" y2="11" /><line x1="15" y1="9" x2="13" y2="11" />
    <path d="M8 16s1.5-1.5 4-1.5 4 1.5 4 1.5" />
  </svg>
);

// ============================================================
// STYLES
// ============================================================
const globalCSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Mono:wght@300;400;500&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #080A0E; color: #E8E8E8; font-family: 'Syne', sans-serif; }
  ::-webkit-scrollbar { width: 4px; } 
  ::-webkit-scrollbar-track { background: #0D0F14; }
  ::-webkit-scrollbar-thumb { background: #222; border-radius: 2px; }
  @keyframes scanDown { 0% { top: 5%; opacity: 1; } 100% { top: 95%; opacity: 0; } }
  @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.4; } }
  @keyframes spin { to { transform: rotate(360deg); } }
  @keyframes fadeIn { from { opacity:0; transform:translateY(-10px); } to { opacity:1; transform:translateY(0); } }
  @keyframes slideUp { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
  @keyframes splashBar { from { width: 0%; } to { width: 100%; } }
  @keyframes glow { 0%,100% { box-shadow: 0 0 20px rgba(0,229,200,0.3); } 50% { box-shadow: 0 0 40px rgba(0,229,200,0.7); } }
`;

const styles = {
  appRoot: {
    display: "flex",
    height: "100vh",
    overflow: "hidden",
    background: "#080A0E",
    fontFamily: "'Syne', sans-serif",
  },
  splash: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100vh",
    background: "radial-gradient(ellipse at center, #0D1520 0%, #080A0E 70%)",
    fontFamily: "'Syne', sans-serif",
  },
  splashInner: {
    textAlign: "center",
    animation: "slideUp 0.6s ease",
  },
  splashIcon: {
    marginBottom: 24,
    animation: "glow 2s ease-in-out infinite",
    display: "inline-block",
    padding: 20,
    borderRadius: "50%",
    background: "rgba(0,229,200,0.05)",
    border: "1px solid rgba(0,229,200,0.2)",
  },
  splashTitle: {
    fontSize: 48,
    fontWeight: 800,
    color: "#fff",
    letterSpacing: "-2px",
    lineHeight: 1,
  },
  splashSub: {
    color: "#555",
    fontSize: 15,
    marginTop: 8,
    letterSpacing: "2px",
    textTransform: "uppercase",
    fontFamily: "'DM Mono', monospace",
  },
  splashLoader: {
    width: 200,
    height: 2,
    background: "#1A1D24",
    borderRadius: 2,
    margin: "32px auto 12px",
    overflow: "hidden",
  },
  splashBar: {
    height: "100%",
    background: "linear-gradient(90deg, #00E5C8, #4FC3F7)",
    borderRadius: 2,
    animation: "splashBar 1.5s ease forwards",
  },
  splashStatus: {
    color: "#444",
    fontSize: 12,
    fontFamily: "'DM Mono', monospace",
  },

  // Sidebar
  sidebar: {
    width: 220,
    minWidth: 220,
    background: "#0D0F14",
    borderRight: "1px solid #161820",
    display: "flex",
    flexDirection: "column",
    padding: "0",
    overflow: "hidden",
  },
  sidebarHeader: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "24px 20px 16px",
    borderBottom: "1px solid #161820",
  },
  sidebarBrand: {
    display: "block",
    fontSize: 18,
    fontWeight: 800,
    color: "#fff",
    letterSpacing: "-0.5px",
    lineHeight: 1,
  },
  sidebarVersion: {
    display: "block",
    fontSize: 9,
    color: "#00E5C8",
    fontFamily: "'DM Mono', monospace",
    letterSpacing: "1px",
    marginTop: 2,
  },
  sidebarStats: {
    padding: "12px 20px",
    borderBottom: "1px solid #161820",
    display: "flex",
    alignItems: "baseline",
    gap: 8,
  },
  sidebarStatNum: {
    fontSize: 28,
    fontWeight: 800,
    color: "#00E5C8",
    lineHeight: 1,
  },
  sidebarStatLabel: {
    fontSize: 11,
    color: "#555",
    textTransform: "uppercase",
    letterSpacing: "1px",
  },
  sidebarNav: {
    flex: 1,
    padding: "8px 0",
    overflow: "auto",
  },
  navBtn: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    width: "100%",
    padding: "11px 20px",
    background: "none",
    border: "none",
    cursor: "pointer",
    color: "#555",
    fontSize: 13,
    fontFamily: "'Syne', sans-serif",
    fontWeight: 500,
    letterSpacing: "0.2px",
    position: "relative",
    transition: "all 0.15s",
    textAlign: "left",
  },
  navBtnActive: {
    color: "#fff",
    background: "rgba(0,229,200,0.05)",
  },
  navIcon: {
    opacity: 0.4,
    transition: "opacity 0.15s",
  },
  navIconActive: {
    opacity: 1,
    color: "#00E5C8",
  },
  navLabel: { flex: 1 },
  navIndicator: {
    position: "absolute",
    right: 0,
    top: "20%",
    bottom: "20%",
    width: 2,
    background: "#00E5C8",
    borderRadius: "2px 0 0 2px",
    boxShadow: "0 0 8px #00E5C8",
  },
  sidebarFooter: {
    padding: "16px 20px",
    borderTop: "1px solid #161820",
  },
  clockWidget: {},
  clock: {},
  clockTime: {
    fontSize: 20,
    fontWeight: 700,
    color: "#fff",
    fontFamily: "'DM Mono', monospace",
    letterSpacing: "1px",
  },
  clockDate: {
    fontSize: 11,
    color: "#555",
    marginTop: 2,
    fontFamily: "'DM Mono', monospace",
  },

  // Main content
  mainContent: {
    flex: 1,
    overflow: "auto",
    background: "#080A0E",
  },

  // Pages
  page: {
    padding: "28px 32px",
    maxWidth: 1200,
    margin: "0 auto",
  },
  pageHeader: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginBottom: 28,
  },
  pageTitle: {
    fontSize: 28,
    fontWeight: 800,
    color: "#fff",
    letterSpacing: "-1px",
    lineHeight: 1.1,
  },
  pageSubtitle: {
    fontSize: 13,
    color: "#555",
    marginTop: 6,
    fontFamily: "'DM Mono', monospace",
  },

  // Buttons
  primaryBtn: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 20px",
    background: "linear-gradient(135deg, #00E5C8, #00B4A0)",
    color: "#000",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 700,
    fontFamily: "'Syne', sans-serif",
    letterSpacing: "0.3px",
    transition: "all 0.2s",
  },
  ghostBtn: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 20px",
    background: "transparent",
    color: "#888",
    border: "1px solid #222",
    borderRadius: 8,
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 600,
    fontFamily: "'Syne', sans-serif",
    transition: "all 0.2s",
  },
  editBtn: {
    display: "flex",
    alignItems: "center",
    gap: 5,
    padding: "6px 12px",
    background: "rgba(255,255,255,0.04)",
    color: "#888",
    border: "1px solid #1E2030",
    borderRadius: 6,
    cursor: "pointer",
    fontSize: 12,
    fontFamily: "'Syne', sans-serif",
    fontWeight: 600,
  },
  deactivateBtn: {
    display: "flex",
    alignItems: "center",
    gap: 5,
    padding: "6px 12px",
    background: "rgba(255,82,82,0.05)",
    color: "#FF5252",
    border: "1px solid rgba(255,82,82,0.2)",
    borderRadius: 6,
    cursor: "pointer",
    fontSize: 12,
    fontFamily: "'Syne', sans-serif",
    fontWeight: 600,
  },
  viewAllBtn: {
    marginTop: 12,
    background: "none",
    border: "none",
    color: "#00E5C8",
    fontSize: 13,
    cursor: "pointer",
    fontFamily: "'Syne', sans-serif",
    fontWeight: 600,
  },

  // Dashboard
  statsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)",
    gap: 16,
    marginBottom: 24,
  },
  statCard: {
    padding: 20,
    borderRadius: 12,
    border: "1px solid",
    position: "relative",
    overflow: "hidden",
  },
  statIcon: {
    marginBottom: 12,
    opacity: 0.8,
  },
  statValue: {
    fontSize: 40,
    fontWeight: 800,
    color: "#fff",
    lineHeight: 1,
    letterSpacing: "-2px",
  },
  statLabel: {
    fontSize: 12,
    color: "#666",
    marginTop: 8,
    textTransform: "uppercase",
    letterSpacing: "1px",
    fontFamily: "'DM Mono', monospace",
  },
  statAccent: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 2,
    opacity: 0.6,
  },
  dashRow: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 16,
  },
  dashCard: {
    background: "#0D0F14",
    borderRadius: 12,
    border: "1px solid #161820",
    padding: 20,
  },
  dashCardTitle: {
    fontSize: 14,
    fontWeight: 700,
    color: "#fff",
    marginBottom: 16,
    textTransform: "uppercase",
    letterSpacing: "1px",
  },
  activityList: {
    display: "flex",
    flexDirection: "column",
    gap: 10,
  },
  activityItem: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "10px 12px",
    background: "#080A0E",
    borderRadius: 8,
    border: "1px solid #111318",
  },
  activityAvatar: {
    width: 36,
    height: 36,
    borderRadius: "50%",
    overflow: "hidden",
    background: "#1A1D24",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  activityInfo: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
  },
  activityName: {
    fontSize: 13,
    fontWeight: 600,
    color: "#fff",
  },
  activityRole: {
    fontSize: 11,
    color: "#555",
    marginTop: 1,
  },
  activityRight: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    gap: 4,
  },
  activityTag: {
    fontSize: 10,
    fontWeight: 700,
    padding: "2px 8px",
    borderRadius: 4,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    fontFamily: "'DM Mono', monospace",
  },
  activityTime: {
    fontSize: 11,
    color: "#555",
    fontFamily: "'DM Mono', monospace",
  },
  overviewGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: 10,
  },
  overviewCard: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 6,
    padding: "12px 8px",
    background: "#080A0E",
    borderRadius: 8,
    border: "1px solid #111318",
  },
  ovAvatar: {
    width: 44,
    height: 44,
    borderRadius: "50%",
    overflow: "hidden",
    background: "#1A1D24",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    border: "2px solid",
  },
  ovInitials: {
    fontSize: 13,
    fontWeight: 700,
    color: "#fff",
  },
  ovName: {
    fontSize: 11,
    fontWeight: 600,
    color: "#ccc",
    textAlign: "center",
  },
  ovStatus: {
    fontSize: 9,
    fontWeight: 700,
    padding: "2px 6px",
    borderRadius: 4,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },

  // Attendance Capture
  captureLayout: {
    display: "grid",
    gridTemplateColumns: "1fr 380px",
    gap: 20,
  },
  cameraPanel: {
    display: "flex",
    flexDirection: "column",
    gap: 12,
  },
  cameraFrame: {
    position: "relative",
    borderRadius: 16,
    overflow: "hidden",
    background: "#0D0F14",
    border: "2px solid",
    transition: "border-color 0.3s, box-shadow 0.3s",
    aspectRatio: "4/3",
  },
  cameraError: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    gap: 12,
  },
  videoFeed: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transform: "scaleX(-1)",
    display: "block",
  },
  faceOverlay: {
    position: "absolute",
    inset: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    pointerEvents: "none",
  },
  faceBox: {
    width: "45%",
    aspectRatio: "3/4",
    border: "1px dashed",
    borderRadius: "50% 50% 40% 40%",
    position: "relative",
    transition: "border-color 0.3s",
  },
  faceCorner: {
    position: "absolute",
    width: 20,
    height: 20,
  },
  scanLine: {
    position: "absolute",
    left: "5%",
    right: "5%",
    height: 1,
    background: "linear-gradient(90deg, transparent, #00E5C8, transparent)",
    animation: "scanDown 2s ease-in-out infinite",
    top: "5%",
  },
  camStatusBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 16px",
    border: "0",
    borderTop: "1px solid",
    backdropFilter: "blur(10px)",
  },
  camStatusDot: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    flexShrink: 0,
    animation: "pulse 1.5s ease infinite",
  },
  camStatusText: {
    fontSize: 12,
    fontWeight: 600,
    fontFamily: "'DM Mono', monospace",
    letterSpacing: "0.3px",
  },
  livenessBar: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "10px 16px",
    background: "#0D0F14",
    borderRadius: 8,
    border: "1px solid #161820",
  },
  livenessLabel: {
    fontSize: 11,
    color: "#555",
    textTransform: "uppercase",
    letterSpacing: "1px",
    fontFamily: "'DM Mono', monospace",
    whiteSpace: "nowrap",
  },
  livenessTrack: {
    flex: 1,
    height: 4,
    background: "#1A1D24",
    borderRadius: 2,
    overflow: "hidden",
  },
  livenessFill: {
    height: "100%",
    borderRadius: 2,
    transition: "width 0.3s, background 0.3s",
  },
  livenessScore: {
    fontSize: 12,
    color: "#888",
    fontFamily: "'DM Mono', monospace",
    minWidth: 36,
    textAlign: "right",
  },
  resultPanel: {
    background: "#0D0F14",
    borderRadius: 16,
    border: "1px solid #161820",
    overflow: "hidden",
  },
  modeToggle: {
    display: "flex",
    background: "#0D0F14",
    border: "1px solid #222",
    borderRadius: 8,
    overflow: "hidden",
  },
  modeBtn: {
    padding: "8px 18px",
    background: "none",
    border: "none",
    color: "#555",
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer",
    fontFamily: "'Syne', sans-serif",
    transition: "all 0.15s",
  },
  modeBtnActive: {
    background: "#00E5C8",
    color: "#000",
  },

  // Waiting panel
  waitingPanel: {
    padding: 24,
    height: "100%",
    display: "flex",
    flexDirection: "column",
  },
  waitingIcon: {
    display: "flex",
    justifyContent: "center",
    marginBottom: 16,
    opacity: 0.7,
  },
  waitingTitle: {
    fontSize: 20,
    fontWeight: 700,
    color: "#fff",
    textAlign: "center",
    marginBottom: 8,
  },
  waitingDesc: {
    fontSize: 13,
    color: "#666",
    textAlign: "center",
    lineHeight: 1.5,
  },
  divider: {
    height: 1,
    background: "#161820",
    margin: "20px 0",
  },
  currentlyIn: {},
  currentlyInTitle: {
    fontSize: 11,
    color: "#555",
    textTransform: "uppercase",
    letterSpacing: "1px",
    fontFamily: "'DM Mono', monospace",
    marginBottom: 12,
  },
  checkedInList: {
    display: "flex",
    flexDirection: "column",
    gap: 8,
  },
  checkedInItem: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "8px 10px",
    background: "rgba(0,229,200,0.04)",
    borderRadius: 8,
    border: "1px solid rgba(0,229,200,0.08)",
  },
  checkedInAvatar: {
    width: 32,
    height: 32,
    borderRadius: "50%",
    overflow: "hidden",
    background: "#1A1D24",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  checkedInInitials: {
    fontSize: 10,
    fontWeight: 700,
    color: "#00E5C8",
  },
  checkedInName: {
    fontSize: 13,
    fontWeight: 600,
    color: "#ddd",
  },
  checkedInTime: {
    fontSize: 11,
    color: "#555",
    fontFamily: "'DM Mono', monospace",
  },

  // Recognition success
  successPanel: {
    padding: 24,
    display: "flex",
    flexDirection: "column",
    gap: 16,
    animation: "fadeIn 0.4s ease",
  },
  successHeader: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 12,
  },
  successAvatarWrap: {
    position: "relative",
    width: 80,
    height: 80,
  },
  successAvatar: {
    width: 80,
    height: 80,
    borderRadius: "50%",
    objectFit: "cover",
    border: "3px solid #00E5C8",
    boxShadow: "0 0 20px rgba(0,229,200,0.4)",
  },
  successAvatarPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: "50%",
    background: "#1A1D24",
    border: "3px solid #00E5C8",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 24,
    fontWeight: 800,
    color: "#00E5C8",
    boxShadow: "0 0 20px rgba(0,229,200,0.4)",
  },
  successBadge: {
    position: "absolute",
    bottom: -2,
    right: -2,
    width: 24,
    height: 24,
    borderRadius: "50%",
    background: "#00E5C8",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    border: "2px solid #0D0F14",
  },
  successCheck: {
    display: "flex",
    alignItems: "center",
    gap: 6,
  },
  successCheckText: {
    fontSize: 14,
    fontWeight: 700,
    color: "#00E5C8",
    textTransform: "uppercase",
    letterSpacing: "1px",
    fontFamily: "'DM Mono', monospace",
  },
  successInfo: {
    textAlign: "center",
  },
  successName: {
    fontSize: 24,
    fontWeight: 800,
    color: "#fff",
    letterSpacing: "-0.5px",
  },
  successRole: {
    fontSize: 14,
    color: "#888",
    marginTop: 4,
  },
  successDept: {
    fontSize: 12,
    color: "#555",
    marginTop: 2,
  },
  successId: {
    fontSize: 12,
    color: "#444",
    fontFamily: "'DM Mono', monospace",
    marginTop: 6,
  },
  checkinInfo: {
    background: "#080A0E",
    borderRadius: 8,
    padding: "12px 16px",
    border: "1px solid #161820",
  },
  checkinInfoRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "4px 0",
  },
  checkinInfoLabel: {
    fontSize: 12,
    color: "#666",
    fontFamily: "'DM Mono', monospace",
  },
  checkinInfoVal: {
    fontSize: 14,
    fontWeight: 700,
    color: "#fff",
    fontFamily: "'DM Mono', monospace",
  },
  successActions: {
    display: "flex",
    flexDirection: "column",
    gap: 8,
  },
  confirmBtn: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: "14px",
    border: "none",
    borderRadius: 10,
    cursor: "pointer",
    fontSize: 15,
    fontWeight: 800,
    fontFamily: "'Syne', sans-serif",
    letterSpacing: "0.3px",
    color: "#000",
    transition: "opacity 0.2s",
  },
  retryBtn: {
    padding: "10px",
    background: "transparent",
    border: "1px solid #222",
    borderRadius: 10,
    color: "#666",
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer",
    fontFamily: "'Syne', sans-serif",
    textAlign: "center",
  },
  timeNow: {
    textAlign: "center",
    fontSize: 20,
    fontWeight: 700,
    color: "#333",
    fontFamily: "'DM Mono', monospace",
  },

  // Employee
  toolbar: {
    display: "flex",
    gap: 12,
    marginBottom: 20,
  },
  searchBox: {
    flex: 1,
    display: "flex",
    alignItems: "center",
    gap: 10,
    background: "#0D0F14",
    border: "1px solid #1A1D24",
    borderRadius: 8,
    padding: "0 14px",
  },
  searchInput: {
    flex: 1,
    background: "none",
    border: "none",
    outline: "none",
    color: "#fff",
    fontSize: 14,
    fontFamily: "'Syne', sans-serif",
    padding: "11px 0",
  },
  filterSelect: {
    background: "#0D0F14",
    border: "1px solid #1A1D24",
    borderRadius: 8,
    color: "#888",
    fontSize: 13,
    padding: "10px 14px",
    fontFamily: "'Syne', sans-serif",
    outline: "none",
    cursor: "pointer",
  },
  empGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
    gap: 14,
  },
  empCard: {
    background: "#0D0F14",
    borderRadius: 12,
    border: "1px solid #161820",
    padding: 16,
    transition: "border-color 0.2s",
  },
  empCardHeader: {
    display: "flex",
    gap: 12,
    marginBottom: 12,
  },
  empAvatar: {
    width: 48,
    height: 48,
    borderRadius: "50%",
    overflow: "hidden",
    background: "#1A1D24",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    position: "relative",
  },
  empInitials: {
    fontSize: 14,
    fontWeight: 700,
    color: "#00E5C8",
  },
  empStatusDot: {
    position: "absolute",
    bottom: 1,
    right: 1,
    width: 10,
    height: 10,
    borderRadius: "50%",
    border: "2px solid #0D0F14",
  },
  empInfo: { flex: 1, minWidth: 0 },
  empName: {
    fontSize: 14,
    fontWeight: 700,
    color: "#fff",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  },
  empRole: {
    fontSize: 12,
    color: "#888",
    marginTop: 2,
  },
  empDept: {
    fontSize: 11,
    color: "#555",
    marginTop: 1,
  },
  empCardMeta: {
    display: "flex",
    gap: 6,
    flexWrap: "wrap",
    marginBottom: 12,
  },
  empIdBadge: {
    fontSize: 10,
    color: "#555",
    background: "#111318",
    padding: "2px 8px",
    borderRadius: 4,
    fontFamily: "'DM Mono', monospace",
  },
  empFaceBadge: {
    fontSize: 10,
    padding: "2px 8px",
    borderRadius: 4,
    fontFamily: "'DM Mono', monospace",
    fontWeight: 600,
  },
  empCardActions: {
    display: "flex",
    gap: 6,
  },

  // Add Employee
  stepIndicator: {
    display: "flex",
    alignItems: "center",
    marginBottom: 24,
    maxWidth: 400,
  },
  stepDot: {
    width: 32,
    height: 32,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#000",
    fontSize: 13,
    fontWeight: 800,
    transition: "background 0.3s",
  },
  stepLine: {
    flex: 1,
    height: 2,
    transition: "background 0.3s",
    margin: "0 8px",
  },
  formCard: {
    background: "#0D0F14",
    borderRadius: 14,
    border: "1px solid #161820",
    padding: 28,
    maxWidth: 900,
  },
  formSection: {
    fontSize: 16,
    fontWeight: 700,
    color: "#fff",
    marginBottom: 20,
    paddingBottom: 12,
    borderBottom: "1px solid #161820",
  },
  formHint: {
    fontSize: 13,
    color: "#666",
    marginBottom: 20,
    lineHeight: 1.5,
  },
  formGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 16,
    marginBottom: 24,
  },
  fieldWrap: {
    display: "flex",
    flexDirection: "column",
    gap: 6,
  },
  fieldLabel: {
    fontSize: 12,
    color: "#666",
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "0.8px",
    fontFamily: "'DM Mono', monospace",
  },
  inputField: {
    padding: "11px 14px",
    background: "#080A0E",
    border: "1px solid",
    borderRadius: 8,
    color: "#fff",
    fontSize: 14,
    fontFamily: "'Syne', sans-serif",
    outline: "none",
    transition: "border-color 0.2s",
  },
  selectField: {
    padding: "11px 14px",
    background: "#080A0E",
    border: "1px solid #222",
    borderRadius: 8,
    color: "#fff",
    fontSize: 14,
    fontFamily: "'Syne', sans-serif",
    outline: "none",
    cursor: "pointer",
  },
  fieldError: {
    fontSize: 11,
    color: "#FF5252",
    fontFamily: "'DM Mono', monospace",
  },
  formActions: {
    display: "flex",
    gap: 10,
    justifyContent: "flex-end",
    paddingTop: 16,
    borderTop: "1px solid #161820",
  },

  // Face enrollment
  faceEnrollLayout: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 20,
    marginBottom: 20,
  },
  faceEnrollCamera: {
    display: "flex",
    flexDirection: "column",
    gap: 10,
  },
  enrollCamFrame: {
    position: "relative",
    borderRadius: 12,
    overflow: "hidden",
    background: "#080A0E",
    border: "2px solid",
    transition: "border-color 0.3s",
    aspectRatio: "4/3",
  },
  videoFeedSmall: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transform: "scaleX(-1)",
    display: "block",
  },
  camLoading: {
    position: "absolute",
    inset: 0,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  spinner: {
    width: 32,
    height: 32,
    border: "2px solid #1A1D24",
    borderTop: "2px solid #00E5C8",
    borderRadius: "50%",
    animation: "spin 0.8s linear infinite",
  },
  enrollStatus: {
    fontSize: 12,
    fontFamily: "'DM Mono', monospace",
    transition: "color 0.3s",
    textAlign: "center",
  },
  captureBtn: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: "12px",
    background: "rgba(0,229,200,0.1)",
    border: "1px solid rgba(0,229,200,0.3)",
    borderRadius: 10,
    color: "#00E5C8",
    fontSize: 14,
    fontWeight: 700,
    fontFamily: "'Syne', sans-serif",
    cursor: "pointer",
    transition: "all 0.2s",
  },
  capturedFaces: {
    display: "flex",
    flexDirection: "column",
    gap: 12,
  },
  capturedTitle: {
    fontSize: 13,
    fontWeight: 700,
    color: "#888",
    textTransform: "uppercase",
    letterSpacing: "1px",
  },
  noFaces: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 8,
    padding: 24,
    color: "#333",
    fontSize: 13,
  },
  faceGrid: {
    display: "flex",
    flexWrap: "wrap",
    gap: 10,
  },
  faceThumbnail: {
    position: "relative",
    width: 88,
    height: 88,
    borderRadius: 8,
    overflow: "hidden",
    border: "2px solid #1A1D24",
  },
  faceThumbImg: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transform: "scaleX(-1)",
  },
  removeFaceBtn: {
    position: "absolute",
    top: 4,
    right: 4,
    width: 20,
    height: 20,
    borderRadius: "50%",
    background: "rgba(255,82,82,0.9)",
    border: "none",
    color: "#fff",
    fontSize: 14,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    lineHeight: 1,
  },
  primaryFaceTag: {
    position: "absolute",
    bottom: 4,
    left: 4,
    right: 4,
    background: "rgba(0,229,200,0.9)",
    color: "#000",
    fontSize: 8,
    fontWeight: 800,
    textAlign: "center",
    padding: "2px 0",
    borderRadius: 3,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  existingFace: {
    display: "flex",
    alignItems: "center",
    padding: "10px 14px",
    background: "rgba(0,229,200,0.05)",
    borderRadius: 8,
    border: "1px solid rgba(0,229,200,0.1)",
  },

  // Logs table
  tableWrap: {
    background: "#0D0F14",
    borderRadius: 12,
    border: "1px solid #161820",
    overflow: "auto",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    minWidth: 700,
  },
  th: {
    padding: "12px 16px",
    textAlign: "left",
    fontSize: 10,
    fontWeight: 700,
    color: "#555",
    textTransform: "uppercase",
    letterSpacing: "1px",
    fontFamily: "'DM Mono', monospace",
    borderBottom: "1px solid #161820",
    background: "#080A0E",
    whiteSpace: "nowrap",
  },
  td: {
    padding: "12px 16px",
    fontSize: 13,
    color: "#ccc",
    borderBottom: "1px solid #0D0F14",
    fontFamily: "'DM Mono', monospace",
  },
  tr: {
    transition: "background 0.1s",
  },
  tableEmpCell: {
    display: "flex",
    alignItems: "center",
    gap: 10,
  },
  tableAvatar: {
    width: 30,
    height: 30,
    borderRadius: "50%",
    overflow: "hidden",
    background: "#1A1D24",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  tableEmpName: {
    fontSize: 13,
    fontWeight: 600,
    color: "#ddd",
    fontFamily: "'Syne', sans-serif",
  },
  tableEmpId: {
    fontSize: 10,
    color: "#555",
  },
  statusBadge: {
    fontSize: 10,
    fontWeight: 700,
    padding: "3px 10px",
    borderRadius: 4,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  methodBadge: {
    fontSize: 10,
    color: "#555",
    padding: "2px 8px",
    background: "#111318",
    borderRadius: 4,
  },
  pagination: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
    marginTop: 16,
  },
  pageBtn: {
    padding: "8px 16px",
    background: "#0D0F14",
    border: "1px solid #222",
    borderRadius: 6,
    color: "#888",
    fontSize: 13,
    cursor: "pointer",
    fontFamily: "'Syne', sans-serif",
    disabled: { opacity: 0.4, cursor: "default" },
  },
  pageInfo: {
    fontSize: 13,
    color: "#555",
    fontFamily: "'DM Mono', monospace",
  },

  // Settings
  settingsGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 16,
  },
  settingsCard: {
    background: "#0D0F14",
    borderRadius: 12,
    border: "1px solid #161820",
    padding: 24,
  },
  settingsCardTitle: {
    fontSize: 14,
    fontWeight: 700,
    color: "#fff",
    marginBottom: 20,
    textTransform: "uppercase",
    letterSpacing: "1px",
    fontFamily: "'DM Mono', monospace",
  },
  settingsStats: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 12,
  },
  settingsStat: {
    display: "flex",
    flexDirection: "column",
    padding: 14,
    background: "#080A0E",
    borderRadius: 8,
    border: "1px solid #111318",
  },
  settingsStatNum: {
    fontSize: 32,
    fontWeight: 800,
    color: "#fff",
    letterSpacing: "-1px",
    lineHeight: 1,
  },
  settingsStatLabel: {
    fontSize: 11,
    color: "#555",
    marginTop: 6,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  settingsList: {
    display: "flex",
    flexDirection: "column",
    gap: 12,
  },
  settingsItem: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 16,
    padding: "14px 16px",
    background: "#080A0E",
    borderRadius: 8,
    border: "1px solid #111318",
  },
  settingsItemTitle: {
    fontSize: 13,
    fontWeight: 600,
    color: "#ddd",
    marginBottom: 3,
  },
  settingsItemDesc: {
    fontSize: 11,
    color: "#555",
    lineHeight: 1.4,
  },
  storageTag: {
    fontSize: 11,
    color: "#888",
    padding: "4px 10px",
    border: "1px solid #222",
    borderRadius: 4,
    fontFamily: "'DM Mono', monospace",
    whiteSpace: "nowrap",
    flexShrink: 0,
  },

  // Empty states
  emptyState: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 12,
    padding: "40px 20px",
    color: "#555",
    fontSize: 14,
    textAlign: "center",
  },

  // Row action buttons
  rowActions: {
    display: "flex",
    alignItems: "center",
    gap: 6,
  },
  rowEditBtn: {
    display: "flex",
    alignItems: "center",
    gap: 4,
    padding: "5px 10px",
    background: "rgba(79,195,247,0.08)",
    border: "1px solid rgba(79,195,247,0.2)",
    borderRadius: 6,
    color: "#4FC3F7",
    fontSize: 11,
    fontWeight: 700,
    cursor: "pointer",
    fontFamily: "'Syne', sans-serif",
    whiteSpace: "nowrap",
  },
  rowDeleteBtn: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 28,
    height: 28,
    padding: 0,
    background: "rgba(255,82,82,0.06)",
    border: "1px solid rgba(255,82,82,0.2)",
    borderRadius: 6,
    color: "#FF5252",
    fontSize: 14,
    cursor: "pointer",
  },

  // Edit attendance modal
  editModalOverlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.85)",
    backdropFilter: "blur(6px)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 9999,
    animation: "fadeIn 0.2s ease",
  },
  editModalBox: {
    background: "#0D0F14",
    border: "1px solid #1E2030",
    borderRadius: 16,
    padding: 28,
    width: "100%",
    maxWidth: 480,
    boxShadow: "0 24px 80px rgba(0,0,0,0.6)",
    animation: "slideUp 0.25s ease",
  },
  editModalHeader: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
    paddingBottom: 16,
    borderBottom: "1px solid #161820",
  },
  editModalTitle: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    fontSize: 16,
    fontWeight: 800,
    color: "#fff",
  },
  editModalClose: {
    background: "none",
    border: "none",
    color: "#555",
    fontSize: 24,
    cursor: "pointer",
    lineHeight: 1,
    padding: "0 4px",
  },
  editEmpStrip: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "12px 16px",
    background: "rgba(0,229,200,0.04)",
    border: "1px solid rgba(0,229,200,0.1)",
    borderRadius: 10,
    marginBottom: 20,
  },
  editEmpAvatar: {
    width: 44,
    height: 44,
    borderRadius: "50%",
    overflow: "hidden",
    background: "#1A1D24",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    border: "2px solid rgba(0,229,200,0.3)",
  },
  editEmpName: {
    fontSize: 15,
    fontWeight: 700,
    color: "#fff",
  },
  editEmpRole: {
    fontSize: 12,
    color: "#666",
    marginTop: 2,
    fontFamily: "'DM Mono', monospace",
  },
  editFormGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 14,
    marginBottom: 16,
  },
  editFieldWrap: {
    display: "flex",
    flexDirection: "column",
    gap: 6,
  },
  editFieldLabel: {
    fontSize: 11,
    color: "#666",
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "0.8px",
    fontFamily: "'DM Mono', monospace",
  },
  editInput: {
    padding: "10px 12px",
    background: "#080A0E",
    border: "1px solid #222",
    borderRadius: 8,
    color: "#fff",
    fontSize: 14,
    fontFamily: "'Syne', sans-serif",
    outline: "none",
    cursor: "pointer",
    colorScheme: "dark",
  },
  editDurationPreview: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "10px 14px",
    background: "#080A0E",
    borderRadius: 8,
    border: "1px solid #161820",
    marginBottom: 16,
  },
  editDurationLabel: {
    fontSize: 11,
    color: "#555",
    fontFamily: "'DM Mono', monospace",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  editDurationVal: {
    fontSize: 16,
    fontWeight: 800,
    color: "#fff",
    fontFamily: "'DM Mono', monospace",
  },
  editAutoStatus: {
    fontSize: 12,
    fontWeight: 700,
    fontFamily: "'DM Mono', monospace",
    marginLeft: "auto",
  },
  editError: {
    padding: "10px 14px",
    background: "rgba(255,82,82,0.1)",
    border: "1px solid rgba(255,82,82,0.3)",
    borderRadius: 8,
    color: "#FF5252",
    fontSize: 13,
    marginBottom: 16,
  },
  editActions: {
    display: "flex",
    gap: 10,
    justifyContent: "flex-end",
    paddingTop: 16,
    borderTop: "1px solid #161820",
  },

  // Avatar
  avatarImg: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
  },
  avatarInitials: {
    fontSize: 12,
    fontWeight: 700,
    color: "#00E5C8",
  },

  // Toast
  toast: {
    position: "fixed",
    top: 20,
    right: 20,
    padding: "14px 20px",
    borderRadius: 10,
    fontSize: 14,
    fontWeight: 700,
    fontFamily: "'Syne', sans-serif",
    display: "flex",
    alignItems: "center",
    gap: 12,
    zIndex: 9999,
    animation: "fadeIn 0.3s ease",
    boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
    maxWidth: 400,
  },
  toastClose: {
    background: "none",
    border: "none",
    fontSize: 20,
    cursor: "pointer",
    lineHeight: 1,
    marginLeft: "auto",
    opacity: 0.7,
  },

  // Modal
  modalOverlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.8)",
    backdropFilter: "blur(4px)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 9998,
  },
  modalBox: {
    background: "#0D0F14",
    borderRadius: 14,
    border: "1px solid #222",
    padding: 28,
    maxWidth: 420,
    width: "100%",
    animation: "fadeIn 0.2s ease",
  },
  confirmDialog: {},
  confirmTitle: {
    fontSize: 20,
    fontWeight: 800,
    color: "#fff",
    marginBottom: 12,
  },
  confirmMsg: {
    fontSize: 14,
    color: "#888",
    lineHeight: 1.5,
    marginBottom: 24,
  },
  confirmActions: {
    display: "flex",
    gap: 10,
    justifyContent: "flex-end",
  },
};